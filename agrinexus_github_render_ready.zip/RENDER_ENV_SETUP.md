# Render Environment Setup

AgriNexus deploys as two Render web services:

- `agrinexus-provider-engines`: receives provider workflow events.
- `agrinexus-platform`: serves the browser app and sends events to provider engines.

## Generate Values

Run this locally after the provider-engine service has a Render URL:

```powershell
$env:PROVIDER_BASE_URL="https://YOUR-AGRINEXUS-PROVIDER-ENGINES.onrender.com"
npm run render:env
```

The command creates `.env.render.generated`. Do not upload that file to GitHub.

## Paste Into Render

In Render, open each service, go to **Environment**, and paste the matching block:

- Paste the `agrinexus-provider-engines` block into the provider service.
- Paste the `agrinexus-platform` block into the platform service.

Replace these before calling it production:

- `DATABASE_URL`: Render PostgreSQL external database URL.
- `OPENAI_API_KEY`: live OpenAI API key.
- `MAP_TILE_URL`: production map tile URL if not using the default OpenStreetMap tile URL.

The provider API keys must match between both services:

- `AI_PROVIDER_API_KEY`
- `LEARNING_PROVIDER_API_KEY`
- `WORKFORCE_PROVIDER_API_KEY`
- `HEALTH_PROVIDER_API_KEY`
- `TRADE_PROVIDER_API_KEY`

## Verify

After saving Render environment variables and redeploying both services:

```powershell
npm run production:preflight
npm run workforce:live-check
```

In the hosted browser, open:

```text
/status.html
```

The readiness board should show AI, maps, learning, workforce, healthcare, and AgriTrade as live-connected.
