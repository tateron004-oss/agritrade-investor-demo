const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return;
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index === -1) continue;
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim();
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}

loadEnvFile(path.join(__dirname, ".env"));

const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || "127.0.0.1";
const AI_MODEL = process.env.OPENAI_MODEL || "gpt-5.4-mini";
const ROOT = __dirname;
const DATA_DIR = process.env.AGRINEXUS_DATA_DIR || ROOT;
const DB_PATH = process.env.AGRINEXUS_DB_PATH || path.join(DATA_DIR, "db.json");
const PUBLIC = path.join(ROOT, "public");
const REQUIRE_LIVE_SERVICES = process.env.AGRINEXUS_REQUIRE_LIVE_SERVICES === "true";
const STATE_STORE = process.env.AGRINEXUS_STATE_STORE || "json";
const sessions = new Map();
const COUNTRY_LANGUAGE = {
  nigeria: "en",
  kenya: "sw",
  egypt: "ar",
  drc: "fr"
};
const PROVIDER_CONFIG = {
  "learning-courses": { modeEnv: "LEARNING_COURSE_PROVIDER", credentialEnvs: ["LEARNING_COURSE_WEBHOOK_URL", "LEARNING_PROVIDER_API_KEY"] },
  "learning-certificates": { modeEnv: "LEARNING_CERTIFICATE_PROVIDER", credentialEnvs: ["LEARNING_CERTIFICATE_WEBHOOK_URL", "LEARNING_PROVIDER_API_KEY"] },
  "workforce-jobs": { modeEnv: "WORKFORCE_JOB_PROVIDER", credentialEnvs: ["WORKFORCE_JOB_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"] },
  "workforce-calendar": { modeEnv: "WORKFORCE_CALENDAR_PROVIDER", credentialEnvs: ["WORKFORCE_CALENDAR_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"] },
  "workforce-notifications": { modeEnv: "WORKFORCE_NOTIFICATION_PROVIDER", credentialEnvs: ["WORKFORCE_NOTIFICATION_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"] },
  "workforce-hris": { modeEnv: "WORKFORCE_HRIS_PROVIDER", credentialEnvs: ["WORKFORCE_HRIS_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"] },
  "workforce-shifts": { modeEnv: "WORKFORCE_SHIFT_PROVIDER", credentialEnvs: ["WORKFORCE_SHIFT_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"] },
  "health-telehealth": { modeEnv: "HEALTH_TELEHEALTH_PROVIDER", credentialEnvs: ["HEALTH_TELEHEALTH_WEBHOOK_URL", "HEALTH_PROVIDER_API_KEY"] },
  "health-ehr": { modeEnv: "HEALTH_EHR_PROVIDER", credentialEnvs: ["HEALTH_EHR_WEBHOOK_URL", "HEALTH_PROVIDER_API_KEY"] },
  "health-notifications": { modeEnv: "HEALTH_NOTIFICATION_PROVIDER", credentialEnvs: ["HEALTH_NOTIFICATION_WEBHOOK_URL", "HEALTH_PROVIDER_API_KEY"] },
  "trade-payments": { modeEnv: "TRADE_PAYMENT_PROVIDER", credentialEnvs: ["TRADE_PAYMENT_WEBHOOK_URL", "TRADE_PROVIDER_API_KEY"] },
  "trade-logistics": { modeEnv: "TRADE_LOGISTICS_PROVIDER", credentialEnvs: ["TRADE_LOGISTICS_WEBHOOK_URL", "TRADE_PROVIDER_API_KEY"] },
  "trade-market": { modeEnv: "TRADE_MARKET_PROVIDER", credentialEnvs: ["TRADE_MARKET_WEBHOOK_URL", "TRADE_PROVIDER_API_KEY"] }
};

const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

let pgPool = null;
let pgStateReady = false;

function usingPostgresState() {
  return STATE_STORE === "postgres";
}

function postgresConfig() {
  return {
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : false
  };
}

function getPgPool() {
  if (!pgPool) {
    const { Pool } = require("pg");
    pgPool = new Pool(postgresConfig());
  }
  return pgPool;
}

async function ensurePostgresState() {
  if (pgStateReady) return;
  if (!process.env.DATABASE_URL) throw new Error("AGRINEXUS_STATE_STORE=postgres requires DATABASE_URL.");
  const pool = getPgPool();
  await pool.query(`
    create table if not exists agrinexus_app_state (
      id text primary key,
      state jsonb not null,
      updated_at timestamptz not null default now()
    )
  `);
  const existing = await pool.query("select 1 from agrinexus_app_state where id = $1", ["default"]);
  if (!existing.rowCount) {
    const seed = JSON.parse(fs.readFileSync(path.join(ROOT, "db.json"), "utf8"));
    await pool.query(
      "insert into agrinexus_app_state (id, state) values ($1, $2::jsonb)",
      ["default", JSON.stringify(seed)]
    );
  }
  pgStateReady = true;
}

async function readDb() {
  if (usingPostgresState()) {
    await ensurePostgresState();
    const result = await getPgPool().query("select state from agrinexus_app_state where id = $1", ["default"]);
    return result.rows[0].state;
  }
  ensureRuntimeData();
  return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
}

async function writeDb(db) {
  if (usingPostgresState()) {
    await ensurePostgresState();
    await getPgPool().query(
      "update agrinexus_app_state set state = $2::jsonb, updated_at = now() where id = $1",
      ["default", JSON.stringify(db)]
    );
    return;
  }
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2) + "\n");
}

function ensureRuntimeData() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.copyFileSync(path.join(ROOT, "db.json"), DB_PATH);
  }
}

function send(res, status, body, headers = {}) {
  const payload = typeof body === "string" ? body : JSON.stringify(body);
  res.writeHead(status, {
    "content-type": typeof body === "string" ? "text/plain; charset=utf-8" : "application/json; charset=utf-8",
    ...headers
  });
  res.end(payload);
}

function parseCookies(req) {
  return Object.fromEntries((req.headers.cookie || "").split(";").filter(Boolean).map(part => {
    const [key, ...rest] = part.trim().split("=");
    return [key, decodeURIComponent(rest.join("="))];
  }));
}

function currentUser(req, db) {
  const sid = parseCookies(req).agrinexus_sid;
  const userId = sid && sessions.get(sid);
  return db.users.find(user => user.id === userId) || null;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 1_000_000) reject(new Error("Payload too large"));
    });
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
  });
}

function publicState(db, user) {
  const providers = runtimeProviders(db);
  return {
    user: user && { id: user.id, name: user.name, email: user.email, role: user.role, country: user.country, language: user.language },
    permissions: user ? permissionsForRole(user.role) : {},
    countries: db.countries,
    routes: db.routes,
    courses: db.courses,
    roles: db.roles,
    products: db.products || [],
    providers,
    admin: adminSnapshot(db, providers),
    profile: db.profile
  };
}

function permissionsForRole(role) {
  const all = ["learning", "workforce", "health", "trade", "map", "ai", "integrations", "admin", "profile", "notifications", "governance"];
  const matrix = {
    Admin: all,
    Coordinator: all,
    Learner: ["learning", "workforce", "ai", "profile"],
    "Health Operator": ["health", "map", "ai", "notifications", "profile"],
    "Trade Operator": ["trade", "map", "ai", "notifications", "profile"]
  };
  const allowed = new Set(matrix[role] || matrix.Coordinator);
  return Object.fromEntries(all.map(item => [item, allowed.has(item)]));
}

function canUse(user, area) {
  return Boolean(permissionsForRole(user.role)[area]);
}

function runtimeProviders(db) {
  return (db.providers || []).map(provider => {
    if (provider.id === "database") {
      const hasDatabaseUrl = Boolean(process.env.DATABASE_URL);
      const hasPg = Boolean(loadOptional("pg"));
      const postgresState = usingPostgresState();
      return {
        ...provider,
        mode: postgresState ? "postgresql-state" : hasDatabaseUrl ? "postgresql-ready" : "json-file",
        status: hasDatabaseUrl && hasPg && postgresState ? "connected" : hasDatabaseUrl && hasPg ? (REQUIRE_LIVE_SERVICES ? "needs-runtime" : "connected") : hasDatabaseUrl ? "needs-runtime" : (REQUIRE_LIVE_SERVICES ? "needs-credentials" : "connected"),
        detail: hasDatabaseUrl && hasPg && postgresState
          ? "PostgreSQL state store active; learning, workforce, health, trade, AI, and agent records persist to DATABASE_URL."
          : hasDatabaseUrl && hasPg
          ? "DATABASE_URL and pg are available; set AGRINEXUS_STATE_STORE=postgres to persist app workflow state in PostgreSQL."
          : hasDatabaseUrl
          ? "DATABASE_URL is set; install pg and run migrations to activate PostgreSQL."
          : (REQUIRE_LIVE_SERVICES ? "Strict live mode requires DATABASE_URL for PostgreSQL." : "Local JSON persistence active; PostgreSQL path ready.")
      };
    }
    if (provider.id === "openai") {
      const hasLocalAi = Boolean(process.env.AI_PROVIDER === "webhook" && process.env.AI_WEBHOOK_URL && process.env.AI_PROVIDER_API_KEY);
      return {
        ...provider,
        mode: process.env.OPENAI_API_KEY ? "openai" : hasLocalAi ? "local-ai-webhook" : "fallback",
        status: process.env.OPENAI_API_KEY || hasLocalAi ? "connected" : (REQUIRE_LIVE_SERVICES ? "needs-credentials" : "ready"),
        detail: process.env.OPENAI_API_KEY
          ? `OpenAI configured with ${AI_MODEL}.`
          : hasLocalAi
          ? "Local AI engine configured through webhook provider."
          : (REQUIRE_LIVE_SERVICES ? "Strict live mode requires OPENAI_API_KEY or a configured AI webhook." : "Uses offline guidance until OPENAI_API_KEY is set.")
      };
    }
    if (provider.id === "maps") {
      const mode = process.env.MAP_TILE_PROVIDER || provider.mode;
      const hasTileUrl = Boolean(process.env.MAP_TILE_URL);
      const liveMap = mode === "custom-tile" && hasTileUrl;
      return {
        ...provider,
        mode,
        status: liveMap ? "connected" : (REQUIRE_LIVE_SERVICES ? "needs-credentials" : provider.status),
        detail: mode === "custom-tile"
          ? (hasTileUrl ? "Custom map tile URL configured." : "Set MAP_TILE_URL for a custom map tile provider.")
          : REQUIRE_LIVE_SERVICES
          ? "Strict live mode requires MAP_TILE_PROVIDER=custom-tile and MAP_TILE_URL."
          : provider.detail
      };
    }
    const config = PROVIDER_CONFIG[provider.id];
    if (config) {
      const mode = process.env[config.modeEnv] || provider.mode;
      const isSandbox = mode === "sandbox";
      const hasCredential = config.credentialEnvs.every(key => Boolean(process.env[key]));
      return {
        ...provider,
        mode,
        status: isSandbox ? (REQUIRE_LIVE_SERVICES ? "needs-live-provider" : "connected") : (hasCredential ? "connected" : "needs-credentials"),
        detail: isSandbox
          ? (REQUIRE_LIVE_SERVICES ? `Strict live mode requires ${config.modeEnv} to be set to a live provider and credentials configured.` : provider.detail)
          : (hasCredential ? `${mode} provider configured.` : `Set ${config.credentialEnvs.join(" or ")} to activate ${mode}.`)
      };
    }
    return provider;
  });
}

function integrationStatus(db) {
  const providers = runtimeProviders(db);
  const readiness = productionReadiness(providers);
  const liveGaps = readiness.checks.filter(check => !check.ready);
  return {
    ok: !REQUIRE_LIVE_SERVICES || liveGaps.length === 0,
    service: "agrinexus",
    strictLiveMode: REQUIRE_LIVE_SERVICES,
    mode: process.env.NODE_ENV || "development",
    host: HOST,
    port: PORT,
    dataPath: DB_PATH,
    providers,
    readiness,
    liveGaps,
    requiredEnvironment: {
      database: ["DATABASE_URL", "AGRINEXUS_STATE_STORE=postgres"],
      security: ["SESSION_SECRET", "PASSWORD_PEPPER"],
      ai: ["OPENAI_API_KEY or AI_PROVIDER=webhook + AI_WEBHOOK_URL + AI_PROVIDER_API_KEY"],
      learning: ["LEARNING_COURSE_PROVIDER", "LEARNING_CERTIFICATE_PROVIDER", "LEARNING_*_WEBHOOK_URL", "LEARNING_PROVIDER_API_KEY"],
      workforce: ["WORKFORCE_JOB_PROVIDER", "WORKFORCE_CALENDAR_PROVIDER", "WORKFORCE_NOTIFICATION_PROVIDER", "WORKFORCE_HRIS_PROVIDER", "WORKFORCE_SHIFT_PROVIDER", "WORKFORCE_*_WEBHOOK_URL", "WORKFORCE_PROVIDER_API_KEY"],
      healthcare: ["HEALTH_TELEHEALTH_PROVIDER", "HEALTH_EHR_PROVIDER", "HEALTH_NOTIFICATION_PROVIDER", "HEALTH_*_WEBHOOK_URL", "HEALTH_PROVIDER_API_KEY"],
      agritrade: ["TRADE_PAYMENT_PROVIDER", "TRADE_LOGISTICS_PROVIDER", "TRADE_MARKET_PROVIDER", "TRADE_*_WEBHOOK_URL", "TRADE_PROVIDER_API_KEY"],
      maps: ["MAP_TILE_PROVIDER", "MAP_TILE_URL"]
    },
    timestamp: new Date().toISOString()
  };
}

function productionReadiness(providers) {
  const providerReady = (id, label) => {
    const provider = providers.find(item => item.id === id);
    const localModes = ["sandbox", "fallback", "json-file", "tile-provider"];
    const ready = Boolean(provider && provider.status === "connected" && !localModes.includes(provider.mode));
    return {
      id,
      label,
      ready,
      detail: provider
        ? `${provider.name}: ${ready ? "Ready" : provider.detail}`
        : `${label} provider is missing.`
    };
  };
  const moduleReadiness = [
    {
      module: "Core",
      checks: [
        {
          id: "database-url",
          label: "DATABASE_URL",
          ready: Boolean(process.env.DATABASE_URL),
          detail: process.env.DATABASE_URL ? "Configured" : "Set DATABASE_URL for PostgreSQL."
        },
        {
          id: "postgres-state-store",
          label: "PostgreSQL workflow state",
          ready: usingPostgresState() && Boolean(process.env.DATABASE_URL),
          detail: usingPostgresState() ? "AGRINEXUS_STATE_STORE=postgres is active." : "Set AGRINEXUS_STATE_STORE=postgres so learning and workforce workflow state persists to PostgreSQL."
        },
        {
          id: "pg-package",
          label: "pg package",
          ready: Boolean(loadOptional("pg")),
          detail: loadOptional("pg") ? "Installed" : "Run npm install when npm is available."
        },
        {
          id: "session-secret",
          label: "SESSION_SECRET",
          ready: Boolean(process.env.SESSION_SECRET && !process.env.SESSION_SECRET.includes("dev-only")),
          detail: process.env.SESSION_SECRET ? "Configured" : "Set SESSION_SECRET for production auth."
        }
      ]
    },
    {
      module: "Learning",
      checks: [
        providerReady("learning-courses", "Course catalog provider"),
        providerReady("learning-certificates", "Certificate provider")
      ]
    },
    {
      module: "Workforce",
      checks: [
        providerReady("workforce-jobs", "Live job network provider"),
        providerReady("workforce-calendar", "Calendar provider"),
        providerReady("workforce-notifications", "Notification provider"),
        providerReady("workforce-hris", "HRIS provider"),
        providerReady("workforce-shifts", "Shift scheduling provider")
      ]
    },
    {
      module: "Healthcare",
      checks: [
        providerReady("health-telehealth", "Telehealth provider"),
        providerReady("health-ehr", "EHR provider"),
        providerReady("health-notifications", "Notification provider")
      ]
    },
    {
      module: "AgriTrade",
      checks: [
        providerReady("trade-payments", "Payment provider"),
        providerReady("trade-logistics", "Logistics provider"),
        providerReady("trade-market", "Market provider")
      ]
    },
    {
      module: "AI & Maps",
      checks: [
        {
          id: "openai-key",
          label: "OPENAI_API_KEY",
          ready: Boolean(process.env.OPENAI_API_KEY),
          detail: process.env.OPENAI_API_KEY ? "Configured" : "Set OPENAI_API_KEY for live AI."
        },
        {
          id: "map-provider",
          label: "Map tile provider",
          ready: Boolean(providers.find(item => item.id === "maps")?.status === "connected"),
          detail: providers.find(item => item.id === "maps")?.detail || "Configure map tiles."
        }
      ]
    }
  ].map(item => {
    const readyCount = item.checks.filter(check => check.ready).length;
    return { ...item, readyCount, total: item.checks.length, status: readyCount === item.checks.length ? "production-ready" : "needs-setup" };
  });
  const checks = moduleReadiness.flatMap(item => item.checks.map(check => ({ ...check, module: item.module })));
  const legacyChecks = [
    {
      id: "database-url",
      label: "DATABASE_URL",
      ready: Boolean(process.env.DATABASE_URL),
      detail: process.env.DATABASE_URL ? "Configured" : "Set DATABASE_URL for PostgreSQL."
    },
    {
      id: "pg-package",
      label: "pg package",
      ready: Boolean(loadOptional("pg")),
      detail: loadOptional("pg") ? "Installed" : "Run npm install when npm is available."
    },
    {
      id: "openai-key",
      label: "OPENAI_API_KEY",
      ready: Boolean(process.env.OPENAI_API_KEY),
      detail: process.env.OPENAI_API_KEY ? "Configured" : "Set OPENAI_API_KEY for live AI."
    },
    {
      id: "session-secret",
      label: "SESSION_SECRET",
      ready: Boolean(process.env.SESSION_SECRET && !process.env.SESSION_SECRET.includes("dev-only")),
      detail: process.env.SESSION_SECRET ? "Configured" : "Set SESSION_SECRET for production auth."
    },
    {
      id: "provider-modes",
      label: "Provider modes",
      ready: providers.every(provider => !["fallback"].includes(provider.mode)),
      detail: "Sandbox providers are connected locally; live credentials can replace them."
    }
  ];
  const readyCount = checks.filter(check => check.ready).length;
  return {
    status: readyCount === checks.length ? "production-ready" : "local-optimized",
    readyCount,
    total: checks.length,
    checks,
    legacyChecks,
    moduleReadiness,
    nextSteps: checks.filter(check => !check.ready).map(check => `${check.module}: ${check.detail}`)
  };
}

function loadOptional(name) {
  try {
    return require(name);
  } catch {
    return null;
  }
}

function adminSnapshot(db, providers = runtimeProviders(db)) {
  const profile = db.profile || {};
  const modules = [
    { name: "Learning", status: "connected", records: (profile.enrollments || []).length + (profile.certificates || []).length },
    { name: "Workforce", status: "connected", records: (profile.applications || []).length + (profile.shiftSchedule || []).length },
    { name: "Healthcare", status: "connected", records: (profile.healthIntakes || []).length + (profile.carePlans || []).length + (profile.safetyReviews || []).length },
    { name: "AgriTrade", status: "connected", records: (profile.orders || []).length + (profile.walletTransactions || []).length },
    { name: "Integrations", status: "connected", records: (profile.integrationEvents || []).length },
    { name: "Maps/AI", status: "ready", records: (db.routes || []).length + (db.countries || []).length }
  ];
  return {
    users: (db.users || []).map(user => ({ id: user.id, name: user.name, email: user.email, role: user.role, country: user.country })),
    modules,
    readiness: productionReadiness(providers),
    audit: [
      ...(profile.activity || []).map(item => ({ type: "activity", detail: item })),
      ...(profile.integrationEvents || []).map(item => ({ type: "integration", detail: `${item.providerName}: ${item.action}` })),
      ...(profile.tradeEvents || []).map(item => ({ type: "trade", detail: item.label }))
    ].slice(0, 30)
  };
}

function routeByProduct(db, product) {
  const productRecord = (db.products || []).find(item => item.id === product || item.name === product);
  const country = productRecord
    ? db.countries.find(item => item.id === productRecord.countryId)
    : db.countries.find(item => String(product || "").toLowerCase().includes(item.name.toLowerCase())) || db.countries[0];
  return { country, route: db.routes.find(item => item.id === country.routeId) };
}

function activeContext(db) {
  const country = db.countries.find(item => item.id === db.profile.activeCountryId) || db.countries[0];
  const route = db.routes.find(item => item.id === db.profile.activeRouteId) || db.routes[0];
  return { country, route };
}

function addActivity(profile, message) {
  profile.activity.unshift(`${new Date().toISOString()} ${message}`);
  profile.activity = profile.activity.slice(0, 25);
}

function addWorkflowNote(profile, note, label = "Workflow note") {
  const clean = String(note || "").trim();
  if (clean) addActivity(profile, `${label}: ${clean}`);
}

function providerRuntime(providerId) {
  const config = PROVIDER_CONFIG[providerId];
  if (!config) return { mode: "local", webhookUrl: "", apiKey: "" };
  const webhookKey = config.credentialEnvs.find(key => key.endsWith("_WEBHOOK_URL"));
  const apiKey = config.credentialEnvs.find(key => key.endsWith("_API_KEY"));
  return {
    mode: process.env[config.modeEnv] || "sandbox",
    webhookUrl: webhookKey ? process.env[webhookKey] || "" : "",
    apiKey: apiKey ? process.env[apiKey] || "" : ""
  };
}

async function dispatchProviderWebhook(db, event) {
  const provider = (db.providers || []).find(item => item.id === event.providerId);
  const runtime = providerRuntime(event.providerId);
  if (!provider || runtime.mode === "sandbox") {
    if (REQUIRE_LIVE_SERVICES && provider) {
      return { attempted: false, ok: false, status: "strict-live-provider-required" };
    }
    return { attempted: false, ok: true, status: "sandbox" };
  }
  if (!runtime.webhookUrl) {
    return { attempted: false, ok: false, status: "missing-webhook" };
  }

  const response = await fetch(runtime.webhookUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(runtime.apiKey ? { authorization: `Bearer ${runtime.apiKey}` } : {})
    },
    body: JSON.stringify({
      id: crypto.randomUUID(),
      providerId: event.providerId,
      providerName: provider.name,
      module: event.module,
      action: event.action,
      detail: event.detail,
      metadata: event.metadata || {},
      createdAt: new Date().toISOString()
    })
  });

  return { attempted: true, ok: response.ok, status: response.status };
}

function logIntegration(db, { providerId, module, action, status = "success", detail, metadata = {}, dispatch = true }) {
  db.profile.integrationEvents = db.profile.integrationEvents || [];
  const provider = (db.providers || []).find(item => item.id === providerId);
  const event = {
    providerId,
    module,
    action,
    status,
    detail,
    metadata
  };
  db.profile.integrationEvents.unshift({
    id: crypto.randomUUID(),
    providerId,
    providerName: provider?.name || providerId,
    module,
    action,
    status,
    detail,
    metadata,
    createdAt: new Date().toISOString()
  });
  db.profile.integrationEvents = db.profile.integrationEvents.slice(0, 50);
  if (dispatch) {
    dispatchProviderWebhook(db, event).catch(error => {
      console.warn(`Provider dispatch failed for ${providerId}: ${error.message}`);
    });
  }
}

function recalcReadiness(profile) {
  if (profile.readiness >= 55) profile.eligibility = "Eligible";
  if (profile.readiness >= 75) profile.careerTrack = "Placement Pathway";
  if (profile.readiness >= 90) profile.careerTrack = "Leadership Pathway";
  if (profile.readiness >= 55) profile.learningPath = "Workforce Eligible";
  if (profile.readiness >= 75) profile.learningPath = "Placement Pathway";
  if (profile.readiness >= 90) profile.learningPath = "Leadership Pathway";
}

function ensureLearningProfile(profile) {
  profile.enrollments = profile.enrollments || [];
  profile.completedCourses = profile.completedCourses || [];
  profile.certificates = profile.certificates || [];
  profile.learningPath = profile.learningPath || "Foundation Pathway";
  profile.learningStreak = profile.learningStreak || 0;
  profile.learningHours = profile.learningHours || 0;
  profile.accessibilityProfile = profile.accessibilityProfile || {
    hearingSupport: true,
    visualSupport: true,
    preferredFormats: ["captions", "screen-reader", "large-print", "audio-guide", "offline-packet"],
    language: profile.language || "sw",
    bandwidth: "low",
    representative: "Community accessibility aide"
  };
  profile.learningAccommodations = profile.learningAccommodations || [];
}

function getEnrollment(profile, courseId) {
  ensureLearningProfile(profile);
  return profile.enrollments.find(item => item.courseId === courseId) || null;
}

function ensureWorkforceProfile(profile) {
  profile.applications = profile.applications || [];
  profile.shiftSchedule = profile.shiftSchedule || [];
  profile.workforceBadges = profile.workforceBadges || [];
  profile.mentorNotes = profile.mentorNotes || [];
  profile.interviews = profile.interviews || 0;
  profile.placements = profile.placements || 0;
  profile.mentor = profile.mentor || "Not yet";
  profile.nextShift = profile.nextShift || "Awaiting scheduling";
}

function roleReadiness(profile, role) {
  ensureLearningProfile(profile);
  const missingCertificates = (role.requiredCertificates || []).filter(courseId => !profile.completedCourses.includes(courseId));
  return {
    eligible: profile.readiness >= role.minReadiness && missingCertificates.length === 0,
    missingReadiness: Math.max(0, role.minReadiness - profile.readiness),
    missingCertificates
  };
}

function ensureHealthProfile(profile) {
  profile.healthIntakes = profile.healthIntakes || [];
  profile.carePlans = profile.carePlans || [];
  profile.safetyReviews = profile.safetyReviews || [];
  profile.representativeConnections = profile.representativeConnections || 0;
  profile.accessibilityProfile = profile.accessibilityProfile || {
    hearingSupport: true,
    visualSupport: true,
    preferredFormats: ["captions", "screen-reader", "large-print", "audio-guide", "offline-packet"],
    language: profile.language || "sw",
    bandwidth: "low",
    representative: "Community accessibility aide"
  };
  profile.telehealthAccessibility = profile.telehealthAccessibility || [];
}

function ensureTradeProfile(profile) {
  profile.orders = profile.orders || [];
  profile.walletTransactions = profile.walletTransactions || [];
  profile.tradeEvents = profile.tradeEvents || [];
}

function ensureAiProfile(profile) {
  profile.aiRuns = profile.aiRuns || [];
  profile.mapInsights = profile.mapInsights || [];
  profile.demoMoments = profile.demoMoments || [];
  profile.demoScore = profile.demoScore || 0;
  profile.agentPlans = profile.agentPlans || [];
  profile.agentExecutions = profile.agentExecutions || [];
}

function buildAgentPlan(db, goal, user) {
  const { country, route } = activeContext(db);
  const course = db.courses.find(item => item.id === db.profile.activeCourseId) || db.courses[0];
  const role = db.roles.find(item => roleReadiness(db.profile, item).eligible) || db.roles[0];
  const product = (db.products || []).find(item => item.countryId === country.id) || (db.products || [])[0];
  const steps = [
    { id: crypto.randomUUID(), module: "Learning", tool: "learning.start_or_continue", action: "Prepare course path", detail: `Use ${course?.title || "active course"} as the training path and create learning evidence.`, status: "pending-approval" },
    { id: crypto.randomUUID(), module: "Workforce", tool: "workforce.match_role", action: "Match to role", detail: `Compare readiness against ${role?.title || "available role"} and prepare workforce evidence.`, status: "pending-approval" },
    { id: crypto.randomUUID(), module: "Healthcare", tool: "health.accessibility_review", action: "Prepare accessible telehealth", detail: `Create caption, audio, representative, and low-bandwidth support context for ${country.name}.`, status: "pending-approval" },
    { id: crypto.randomUUID(), module: "AgriTrade", tool: "trade.market_review", action: "Review trade opportunity", detail: `Review ${product?.name || "available product"} and logistics handoff evidence.`, status: "pending-approval" },
    { id: crypto.randomUUID(), module: "Maps", tool: "map.route_risk", action: "Assess route risk", detail: `Analyze ${route.name} at ${db.profile.activeCheckpoint}.`, status: "pending-approval" },
    { id: crypto.randomUUID(), module: "AI", tool: "ai.copilot", action: "Generate supervised recommendation", detail: "Run AI copilot and keep the output in human review.", status: "pending-approval" }
  ];
  return {
    id: crypto.randomUUID(),
    goal,
    status: "awaiting-approval",
    createdBy: user.email,
    countryId: country.id,
    routeId: route.id,
    steps,
    createdAt: new Date().toISOString()
  };
}

function addTradeEvent(profile, event) {
  ensureTradeProfile(profile);
  profile.tradeEvents.unshift({ id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...event });
  profile.tradeEvents = profile.tradeEvents.slice(0, 30);
}

function addNotification(profile, notice) {
  profile.notifications = profile.notifications || [];
  profile.notifications.unshift({ id: crypto.randomUUID(), createdAt: new Date().toISOString(), status: "sent", ...notice });
  profile.notifications = profile.notifications.slice(0, 50);
}

function addMapInsight(profile, insight) {
  ensureAiProfile(profile);
  profile.mapInsights.unshift({ id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...insight });
  profile.mapInsights = profile.mapInsights.slice(0, 20);
}

function recordAiRun(db, { type, country, route, result, module = "AI" }) {
  ensureAiProfile(db.profile);
  db.profile.aiActivity = result.text;
  db.profile.aiProvider = result.provider;
  db.profile.aiModel = result.model;
  db.profile.aiResponseId = result.responseId || null;
  db.profile.aiError = result.error || null;
  const run = {
    id: crypto.randomUUID(),
    type,
    countryId: country.id,
    countryName: country.name,
    routeId: route.id,
    routeName: route.name,
    checkpoint: db.profile.activeCheckpoint,
    routeStage: db.profile.routeStage,
    provider: result.provider,
    model: result.model,
    responseId: result.responseId || null,
    error: result.error || null,
    text: result.text,
    reviewStatus: "pending-human-review",
    reviewedBy: null,
    reviewedAt: null,
    reviewNote: "",
    createdAt: new Date().toISOString()
  };
  db.profile.aiRuns.unshift(run);
  db.profile.aiRuns = db.profile.aiRuns.slice(0, 25);
  addMapInsight(db.profile, {
    type,
    label: `${type} analysis for ${country.name}`,
    detail: result.text,
    routeName: route.name,
    checkpoint: db.profile.activeCheckpoint
  });
  logIntegration(db, {
    providerId: "openai",
    module,
    action: "ai.run",
    status: result.error ? "fallback" : "success",
    detail: `${type} AI run completed through ${result.provider}.`,
    metadata: { runId: run.id, countryId: country.id, routeId: route.id, provider: result.provider }
  });
  return run;
}

async function executeAgentTool(db, user, step) {
  const { country, route } = activeContext(db);
  if (step.tool === "learning.start_or_continue") {
    ensureLearningProfile(db.profile);
    const course = db.courses.find(item => item.id === db.profile.activeCourseId) || db.courses[0];
    if (!course) throw new Error("No course catalog is available.");
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "in_progress",
        progress: 25,
        score: 0,
        startedAt: new Date().toISOString(),
        completedAt: null,
        activeModuleIndex: 0,
        completedModules: []
      };
      db.profile.enrollments.unshift(enrollment);
    } else {
      enrollment.progress = Math.min(100, Number(enrollment.progress || 0) + 25);
      enrollment.status = enrollment.progress >= 100 ? "completed" : "in_progress";
      if (enrollment.progress >= 100 && !enrollment.completedAt) enrollment.completedAt = new Date().toISOString();
    }
    db.profile.activeCourseId = course.id;
    db.profile.readiness = Math.min(100, Number(db.profile.readiness || 0) + Math.max(2, Math.round((course.readiness || 8) / 2)));
    db.profile.learningHours = Number((Number(db.profile.learningHours || 0) + 0.5).toFixed(2));
    db.profile.learningStreak = Number(db.profile.learningStreak || 0) + 1;
    recalcReadiness(db.profile);
    logIntegration(db, {
      providerId: "learning-courses",
      module: "Learning",
      action: "agent.learning_progress",
      detail: `Agent advanced ${course.title} to ${enrollment.progress}% for ${user.email}.`,
      metadata: { courseId: course.id, enrollmentId: enrollment.id, progress: enrollment.progress }
    });
    return `Advanced ${course.title} to ${enrollment.progress}% and updated readiness.`;
  }

  if (step.tool === "workforce.match_role") {
    ensureWorkforceProfile(db.profile);
    const role = db.roles.find(item => roleReadiness(db.profile, item).eligible) || db.roles[0];
    if (!role) throw new Error("No workforce role catalog is available.");
    const readiness = roleReadiness(db.profile, role);
    if (!db.profile.workforceBadges.includes("Profile Verified")) db.profile.workforceBadges.push("Profile Verified");
    let application = db.profile.applications.find(item => item.roleId === role.id);
    if (readiness.eligible && !application) {
      application = {
        id: crypto.randomUUID(),
        roleId: role.id,
        roleTitle: role.title,
        status: "agent-submitted",
        submittedAt: new Date().toISOString(),
        rate: role.rate
      };
      db.profile.applications.unshift(application);
      db.profile.candidateStage = "Agent Matched";
      db.profile.placements = db.profile.applications.length;
    } else {
      db.profile.candidateStage = readiness.eligible ? "Agent Matched" : "Readiness Gap Review";
    }
    logIntegration(db, {
      providerId: "workforce-jobs",
      module: "Workforce",
      action: "agent.workforce_match",
      detail: readiness.eligible
        ? `Agent matched candidate to ${role.title}.`
        : `Agent found readiness gaps for ${role.title}: ${readiness.missingReadiness}% readiness and ${readiness.missingCertificates.length} certificate gap(s).`,
      metadata: { roleId: role.id, eligible: readiness.eligible, applicationId: application?.id || null, readiness }
    });
    return readiness.eligible ? `Matched candidate to ${role.title}.` : `Prepared gap review for ${role.title}.`;
  }

  if (step.tool === "health.accessibility_review") {
    ensureHealthProfile(db.profile);
    let intake = db.profile.healthIntakes[0];
    if (!intake) {
      intake = {
        id: crypto.randomUUID(),
        patientRef: `AN-PAT-${country.id.toUpperCase()}-AGENT`,
        patientName: "Agent-prepared patient",
        countryId: country.id,
        needSummary: `${country.name} agent intake for accessibility and care support`,
        riskLevel: country.risk === "High" || country.heat >= 38 ? "High" : "Routine",
        queueStatus: "Agent access review",
        representativeStatus: "Accessibility aide pending",
        preferredLanguage: db.profile.accessibilityProfile.language || user.language || "en",
        accessibilityNeeds: "Captions, audio narration, large print, caregiver handoff, low-bandwidth callback",
        contactMethod: "Low-bandwidth callback",
        caregiverName: "Community accessibility aide",
        assistiveSupports: ["caption relay", "audio narration", "large-print summary", "caregiver handoff", "low-bandwidth callback"],
        createdAt: new Date().toISOString()
      };
      db.profile.healthIntakes.unshift(intake);
    }
    const record = {
      id: crypto.randomUUID(),
      intakeId: intake.id,
      patientRef: intake.patientRef,
      countryId: country.id,
      title: "Agent accessibility review",
      status: "Agent access plan ready",
      language: intake.preferredLanguage || user.language || "en",
      supports: intake.assistiveSupports || ["caption relay", "audio narration", "caregiver handoff"],
      createdAt: new Date().toISOString()
    };
    db.profile.telehealthAccessibility.unshift(record);
    intake.queueStatus = "Agent access plan ready";
    logIntegration(db, {
      providerId: "health-telehealth",
      module: "Healthcare",
      action: "agent.health_accessibility",
      detail: `Agent prepared accessible telehealth support for ${intake.patientRef}.`,
      metadata: { intakeId: intake.id, accessibilityId: record.id }
    });
    return `Prepared accessible telehealth support for ${intake.patientRef}.`;
  }

  if (step.tool === "trade.market_review") {
    ensureTradeProfile(db.profile);
    const product = (db.products || []).find(item => item.countryId === country.id) || (db.products || [])[0];
    if (!product) throw new Error("No trade product catalog is available.");
    const order = {
      id: crypto.randomUUID(),
      orderNumber: `AN-ORD-AGENT-${String((db.profile.orders || []).length + 1).padStart(3, "0")}`,
      productId: product.id,
      productName: product.name,
      countryId: country.id,
      routeId: route.id,
      stage: "Agent market review",
      stageIndex: 1,
      checkpoint: db.profile.activeCheckpoint,
      buyerInterest: product.buyerInterest || 70,
      amount: Number(product.price || 100) * 10,
      timeline: [{ label: "Agent market review", checkpoint: db.profile.activeCheckpoint, createdAt: new Date().toISOString() }],
      createdAt: new Date().toISOString()
    };
    db.profile.orders.unshift(order);
    addTradeEvent(db.profile, { type: "agent.market_review", label: `${product.name} market review prepared by agent.` });
    logIntegration(db, {
      providerId: "trade-market",
      module: "AgriTrade",
      action: "agent.trade_market_review",
      detail: `Agent created market review order ${order.orderNumber} for ${product.name}.`,
      metadata: { orderId: order.id, productId: product.id }
    });
    return `Created ${order.orderNumber} market review for ${product.name}.`;
  }

  if (step.tool === "map.route_risk") {
    addMapInsight(db.profile, {
      type: "agent-route-risk",
      label: `Agent route risk for ${country.name}`,
      detail: `${route.name} checked at ${db.profile.activeCheckpoint}; coordinate learning, workforce, telehealth, and logistics actions before advancing.`,
      routeName: route.name,
      checkpoint: db.profile.activeCheckpoint
    });
    logIntegration(db, {
      providerId: "maps",
      module: "Maps",
      action: "agent.map_route_risk",
      detail: `Agent assessed ${route.name} at ${db.profile.activeCheckpoint}.`,
      metadata: { routeId: route.id, countryId: country.id }
    });
    return `Assessed route risk for ${route.name}.`;
  }

  if (step.tool === "ai.copilot") {
    const result = await runAi("copilot", country, route, db.profile);
    const run = recordAiRun(db, { type: "copilot", country, route, result, module: "AI" });
    return `Generated supervised AI recommendation ${run.id}.`;
  }

  throw new Error(`Unknown agent tool: ${step.tool}`);
}

async function executeAgentStepWithRetry(db, user, step, maxAttempts = 2) {
  let lastError = null;
  const providerByModule = {
    Learning: "learning-courses",
    Workforce: "workforce-jobs",
    Healthcare: "health-telehealth",
    AgriTrade: "trade-market",
    Maps: "maps",
    AI: "openai"
  };
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const result = await executeAgentTool(db, user, step);
      logIntegration(db, {
        providerId: providerByModule[step.module] || "openai",
        module: step.module,
        action: `agent.${step.tool}`,
        detail: result,
        metadata: { stepId: step.id, attempts: attempt, executedBy: user.email }
      });
      return {
        ...step,
        status: "executed",
        attempts: attempt,
        result,
        error: null,
        executedAt: new Date().toISOString()
      };
    } catch (error) {
      lastError = error;
    }
  }
  logIntegration(db, {
    providerId: providerByModule[step.module] || "openai",
    module: step.module,
    action: `agent.${step.tool}`,
    status: "failed",
    detail: lastError?.message || "Agent step failed.",
    metadata: { stepId: step.id, attempts: maxAttempts, executedBy: user.email }
  });
  return {
    ...step,
    status: "failed",
    attempts: maxAttempts,
    result: "",
    error: lastError?.message || "Agent step failed.",
    executedAt: new Date().toISOString()
  };
}

function aiModuleForType(type, fallback = "AI") {
  const moduleByType = {
    tutor: "Learning",
    quizgen: "Learning",
    "workforce-coach": "Workforce",
    "interview-prep": "Workforce",
    triage: "Healthcare",
    careplan: "Healthcare",
    inspector: "Healthcare",
    "trade-advisor": "AgriTrade",
    price: "AgriTrade",
    route: "Maps",
    command: "AI",
    copilot: "AI"
  };
  return moduleByType[type] || fallback;
}

function fallbackAi(type, country, route, profile) {
  const responses = {
    tutor: `AI tutor recommends the next learner action: review the active course module, complete the lesson check, and connect the outcome to workforce readiness before moving to the quiz.`,
    quizgen: `AI quiz builder recommends three practical checks: explain the workflow, identify the provider evidence created, and choose the safest next operator action.`,
    "workforce-coach": `AI workforce coach recommends closing readiness gaps first, then preparing the candidate for the best eligible role using certificates, interview status, and mentor support.`,
    "interview-prep": `AI interview prep recommends practicing a short story about training completed, operational reliability, and how the candidate would handle a field workflow escalation.`,
    triage: `AI triage assistant recommends classifying the active ${country.name} case by heat, queue pressure, risk, and representative availability before drafting care guidance.`,
    "trade-advisor": `AI trade advisor recommends reviewing buyer interest, wallet readiness, route checkpoint status, and provider evidence before advancing the next order.`,
    copilot: `AI copilot recommends the next best action across AgriNexus: verify learning progress, keep workforce placement moving, review active health risk, advance the trade route, and confirm provider evidence.`,
    price: `Price AI recommends holding premium lots on ${route.name} while buyer demand is strongest. Prioritize verified buyers, staged release, and route-aware pricing.`,
    soil: `${country.name} soil profile needs moderate support before the next planting cycle. Recommend field sampling, irrigation review, and input planning by district.`,
    disease: `No critical disease warning for ${country.name}; continue targeted monitoring and route-specific crop inspection at ${profile.activeCheckpoint}.`,
    route: `Route risk AI recommends prioritizing ${profile.activeCheckpoint} on ${route.name} because ${country.risk.toLowerCase()} operating risk may affect timing.`,
    careplan: `Care plan for ${country.name}: monitor heat index ${country.heat}C, keep queue status visible, and escalate high-risk cases to a representative.`,
    inspector: `Map inspector confirms ${country.facilities} facilities, ${country.queue.toLowerCase()}, and ${route.checkpoints.length} checkpoints on ${route.name}. Keep field teams focused on ${profile.activeCheckpoint}.`,
    command: `Command center synchronized health, trade, workforce, wallet, and route data for ${country.name}.`
  };
  return {
    text: responses[type] || responses.command,
    provider: "offline-simulation",
    model: null
  };
}

function aiPrompt(type, country, route, profile) {
  return [
    "You are AgriNexus AI, an operations assistant for agriculture, health access, workforce readiness, wallet operations, logistics, and field intelligence.",
    "Return one concise operator-facing recommendation in 2-4 sentences. Be specific, practical, and avoid claiming real-world data beyond the provided context.",
    `Task: ${type}`,
    `Country: ${country.name}`,
    `Program status: ${country.status}`,
    `Patients: ${country.patients}`,
    `Facilities: ${country.facilities}`,
    `Health risk: ${country.risk}`,
    `Heat index: ${country.heat}C`,
    `Queue: ${country.queue}`,
    `Route: ${route.name}`,
    `Checkpoint: ${profile.activeCheckpoint}`,
    `Route stage: ${profile.routeStage}`,
    `Readiness: ${profile.readiness}%`,
    `Learning path: ${profile.learningPath || profile.careerTrack || "Unknown"}`,
    `Certificates: ${(profile.certificates || []).length}`,
    `Applications: ${(profile.applications || []).length}`,
    `Interviews: ${profile.interviews || 0}`,
    `Health intakes: ${(profile.healthIntakes || []).length}`,
    `Care plans: ${(profile.carePlans || []).length}`,
    `Orders: ${profile.orders.length}`,
    `Wallet: $${profile.wallet}`
  ].join("\n");
}

function extractResponseText(payload) {
  if (typeof payload.output_text === "string" && payload.output_text.trim()) return payload.output_text.trim();
  const chunks = [];
  for (const item of payload.output || []) {
    for (const content of item.content || []) {
      if (content.type === "output_text" && content.text) chunks.push(content.text);
      if (content.type === "text" && content.text) chunks.push(content.text);
    }
  }
  return chunks.join("\n").trim();
}

async function runAi(type, country, route, profile) {
  if (!process.env.OPENAI_API_KEY && process.env.AI_PROVIDER === "webhook" && process.env.AI_WEBHOOK_URL) {
    const fallback = fallbackAi(type, country, route, profile);
    try {
      const response = await fetch(process.env.AI_WEBHOOK_URL, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...(process.env.AI_PROVIDER_API_KEY ? { authorization: `Bearer ${process.env.AI_PROVIDER_API_KEY}` } : {})
        },
        body: JSON.stringify({
          type,
          prompt: aiPrompt(type, country, route, profile),
          context: {
            country,
            route,
            activeCheckpoint: profile.activeCheckpoint,
            routeStage: profile.routeStage,
            readiness: profile.readiness,
            wallet: profile.wallet
          }
        })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (REQUIRE_LIVE_SERVICES) throw new Error(`Live AI webhook failed: ${payload.error || response.statusText}`);
        fallback.provider = "offline-after-local-ai-error";
        fallback.error = payload.error || response.statusText;
        return fallback;
      }
      return {
        text: payload.text || payload.output_text || fallback.text,
        provider: "local-ai-webhook",
        model: payload.model || "agrinexus-local-ai",
        responseId: payload.id || null
      };
    } catch (error) {
      if (REQUIRE_LIVE_SERVICES) throw error;
      fallback.provider = "offline-after-local-ai-error";
      fallback.error = error.message;
      return fallback;
    }
  }

  if (!process.env.OPENAI_API_KEY) {
    if (REQUIRE_LIVE_SERVICES) throw new Error("Live AI is required. Set OPENAI_API_KEY or configure AI_PROVIDER=webhook with credentials.");
    return fallbackAi(type, country, route, profile);
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model: AI_MODEL,
      input: aiPrompt(type, country, route, profile),
      max_output_tokens: 260
    })
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (REQUIRE_LIVE_SERVICES) throw new Error(`OpenAI request failed: ${payload.error?.message || response.statusText}`);
    const fallback = fallbackAi(type, country, route, profile);
    fallback.text += ` OpenAI request failed, so offline guidance is shown.`;
    fallback.provider = "offline-after-openai-error";
    fallback.error = payload.error?.message || response.statusText;
    return fallback;
  }

  return {
    text: extractResponseText(payload) || fallbackAi(type, country, route, profile).text,
    provider: "openai",
    model: AI_MODEL,
    responseId: payload.id || null
  };
}

async function api(req, res, url) {
  const db = await readDb();
  const user = currentUser(req, db);

  if (url.pathname === "/api/healthz" && req.method === "GET") {
    const status = integrationStatus(db);
    return send(res, 200, {
      ok: status.ok,
      service: "agrinexus",
      mode: process.env.NODE_ENV || "development",
      port: PORT,
      strictLiveMode: REQUIRE_LIVE_SERVICES,
      checks: {
        database: status.providers.find(provider => provider.id === "database")?.status || "unknown",
        ai: status.providers.find(provider => provider.id === "openai")?.mode || "unknown",
        readiness: status.readiness.status,
        readyCount: status.readiness.readyCount,
        total: status.readiness.total,
        liveGaps: status.liveGaps.length
      },
      timestamp: new Date().toISOString()
    });
  }

  if ((url.pathname === "/api/integrations" || url.pathname === "/api/readiness") && req.method === "GET") {
    return send(res, 200, integrationStatus(db));
  }

  if (url.pathname === "/api/login" && req.method === "POST") {
    const body = await readBody(req);
    const found = db.users.find(item => item.email === body.email && item.password === body.password);
    if (!found) return send(res, 401, { error: "Invalid demo credentials" });
    const sid = crypto.randomBytes(24).toString("hex");
    sessions.set(sid, found.id);
    return send(res, 200, publicState(db, found), { "set-cookie": `agrinexus_sid=${sid}; HttpOnly; SameSite=Lax; Path=/` });
  }

  if (url.pathname === "/api/logout" && req.method === "POST") {
    const sid = parseCookies(req).agrinexus_sid;
    if (sid) sessions.delete(sid);
    return send(res, 200, { ok: true }, { "set-cookie": "agrinexus_sid=; Max-Age=0; Path=/" });
  }

  if (!user) return send(res, 401, { error: "Sign in required" });

  if (url.pathname === "/api/state" && req.method === "GET") {
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/config" && req.method === "GET") {
    return send(res, 200, {
      ai: {
        provider: process.env.OPENAI_API_KEY ? "openai" : "offline-simulation",
        model: process.env.OPENAI_API_KEY ? AI_MODEL : null
      },
      map: {
        provider: "leaflet-openstreetmap",
        requiresNetwork: true
      },
      persistence: usingPostgresState() ? "postgresql" : "json-file"
    });
  }

  if (url.pathname === "/api/integrations/test" && req.method === "POST") {
    if (!canUse(user, "integrations")) return send(res, 403, { error: "Role does not allow integration testing" });
    const body = await readBody(req);
    const provider = (db.providers || []).find(item => item.id === body.providerId);
    if (!provider) return send(res, 404, { error: "Provider not found" });
    const delivery = await dispatchProviderWebhook(db, {
      providerId: provider.id,
      module: provider.module,
      action: "provider.test",
      detail: `${provider.name} provider test from AgriNexus.`,
      metadata: { mode: provider.mode, status: provider.status }
    });
    logIntegration(db, {
      providerId: provider.id,
      module: provider.module,
      action: "provider.test",
      status: delivery.ok ? "success" : "needs-credentials",
      detail: delivery.attempted
        ? `${provider.name} live webhook test returned ${delivery.status}.`
        : `${provider.name} ${delivery.status} test completed.`,
      metadata: { mode: provider.mode, status: provider.status, delivery },
      dispatch: false
    });
    addActivity(db.profile, `${provider.name} integration test completed.`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/integrations/test-all" && req.method === "POST") {
    if (!canUse(user, "integrations")) return send(res, 403, { error: "Role does not allow integration testing" });
    const results = [];
    for (const provider of db.providers || []) {
      let delivery;
      try {
        delivery = await dispatchProviderWebhook(db, {
          providerId: provider.id,
          module: provider.module,
          action: "provider.test",
          detail: `${provider.name} provider test from AgriNexus workflow board.`,
          metadata: { mode: provider.mode, status: provider.status }
        });
      } catch (error) {
        delivery = { attempted: true, ok: false, status: "dispatch-error", error: error.message };
      }
      results.push({ providerId: provider.id, ok: delivery.ok, status: delivery.status });
      logIntegration(db, {
        providerId: provider.id,
        module: provider.module,
        action: "provider.test",
        status: delivery.ok ? "success" : "needs-credentials",
        detail: delivery.attempted
          ? `${provider.name} live webhook test returned ${delivery.status}.`
          : `${provider.name} ${delivery.status} test completed.`,
        metadata: { mode: provider.mode, status: provider.status, delivery },
        dispatch: false
      });
    }
    logIntegration(db, {
      providerId: "openai",
      module: "Integrations",
      action: "provider.test_all",
      detail: `${results.length} provider checks completed from the integration workflow board.`,
      metadata: { results },
      dispatch: false
    });
    addActivity(db.profile, `${results.length} provider integration tests completed.`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/integrations/test-module" && req.method === "POST") {
    if (!canUse(user, "integrations")) return send(res, 403, { error: "Role does not allow module engine testing" });
    const body = await readBody(req);
    const moduleName = String(body.module || "").trim();
    const providers = (db.providers || []).filter(provider => provider.module === moduleName);
    if (!providers.length) return send(res, 404, { error: "Module providers not found" });
    const results = [];
    for (const provider of providers) {
      let delivery;
      try {
        delivery = await dispatchProviderWebhook(db, {
          providerId: provider.id,
          module: provider.module,
          action: "provider.test",
          detail: `${provider.name} ${moduleName} engine test from module workspace.`,
          metadata: { mode: provider.mode, status: provider.status }
        });
      } catch (error) {
        delivery = { attempted: true, ok: false, status: "dispatch-error", error: error.message };
      }
      results.push({ providerId: provider.id, ok: delivery.ok, status: delivery.status });
      logIntegration(db, {
        providerId: provider.id,
        module: provider.module,
        action: "provider.test",
        status: delivery.ok ? "success" : "needs-credentials",
        detail: delivery.attempted
          ? `${provider.name} live module test returned ${delivery.status}.`
          : `${provider.name} ${delivery.status} module test completed.`,
        metadata: { mode: provider.mode, status: provider.status, delivery },
        dispatch: false
      });
    }
    logIntegration(db, {
      providerId: providers[0].id,
      module: moduleName,
      action: "provider.test_module",
      detail: `${moduleName} module engine test completed across ${providers.length} provider(s).`,
      metadata: { results },
      dispatch: false
    });
    addActivity(db.profile, `${moduleName} provider engines tested from module workspace.`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/admin/health-check" && req.method === "POST") {
    if (!canUse(user, "admin")) return send(res, 403, { error: "Role does not allow admin health checks" });
    for (const provider of db.providers || []) {
      logIntegration(db, {
        providerId: provider.id,
        module: provider.module,
        action: "admin.health_check",
        detail: `${provider.name} checked from admin console.`,
        metadata: { mode: provider.mode, status: provider.status }
      });
    }
    addActivity(db.profile, "Admin health check completed across all providers.");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/workflow/record" && req.method === "POST") {
    const body = await readBody(req);
    const moduleName = String(body.module || "Platform").trim();
    const action = String(body.action || "workflow.reviewed").trim();
    const detail = String(body.detail || `${moduleName} workflow reviewed.`).trim();
    const providerByModule = {
      Learning: "learning-certificates",
      Workforce: "workforce-notifications",
      Healthcare: "health-notifications",
      Health: "health-notifications",
      AgriTrade: "trade-logistics",
      Integrations: "openai",
      Admin: "database",
      Map: "maps",
      Profile: "database",
      AI: "openai",
      Platform: "openai"
    };
    const providerId = body.providerId || providerByModule[moduleName] || "openai";
    logIntegration(db, {
      providerId,
      module: moduleName,
      action,
      detail,
      metadata: {
        section: body.section || moduleName.toLowerCase(),
        note: body.note || "",
        createdBy: user.email,
        context: {
          countryId: db.profile.activeCountryId,
          routeId: db.profile.activeRouteId,
          checkpoint: db.profile.activeCheckpoint
        }
      },
      dispatch: false
    });
    addActivity(db.profile, detail);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/demo/run" && req.method === "POST") {
    if (!canUse(user, "admin")) return send(res, 403, { error: "Role does not allow executive demo runs" });
    const { country, route } = activeContext(db);
    ensureLearningProfile(db.profile);
    ensureWorkforceProfile(db.profile);
    ensureHealthProfile(db.profile);
    ensureTradeProfile(db.profile);
    ensureAiProfile(db.profile);

    const course = db.courses.find(item => item.id === db.profile.activeCourseId) || db.courses[0];
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "ready_for_quiz",
        progress: 90,
        score: 25,
        activeModuleIndex: 0,
        completedModules: [0],
        startedAt: new Date().toISOString(),
        completedAt: null
      };
      db.profile.enrollments.unshift(enrollment);
    } else {
      enrollment.status = enrollment.status === "completed" ? "completed" : "ready_for_quiz";
      enrollment.progress = Math.max(enrollment.progress || 0, 90);
      enrollment.score = Math.max(enrollment.score || 0, 25);
      enrollment.completedModules = enrollment.completedModules?.length ? enrollment.completedModules : [0];
    }
    db.profile.activeCourseId = course.id;
    db.profile.quizScore = Math.max(db.profile.quizScore || 0, enrollment.score);
    if (!db.profile.completedCourses.includes(course.id)) db.profile.completedCourses.push(course.id);
    if (!db.profile.certificates.some(item => item.courseId === course.id)) {
      db.profile.certificates.push({
        id: crypto.randomUUID(),
        certificateNumber: `AN-CERT-${String(db.profile.certificates.length + 1).padStart(4, "0")}`,
        courseId: course.id,
        title: course.title,
        issuedAt: new Date().toISOString()
      });
    }
    db.profile.learningStreak += 1;
    db.profile.learningHours = Number((db.profile.learningHours + 1.5).toFixed(1));

    if (!db.profile.workforceBadges.includes("Profile Verified")) db.profile.workforceBadges.push("Profile Verified");
    if (!db.profile.workforceBadges.includes("Mentor Matched")) db.profile.workforceBadges.push("Mentor Matched");
    db.profile.mentor = "Assigned";
    db.profile.candidateStage = "Interview";
    db.profile.interviews = Math.max(db.profile.interviews || 0, 1);
    const role = db.roles.find(item => roleReadiness(db.profile, item).eligible) || db.roles[0];
    if (role && !db.profile.applications.some(item => item.roleId === role.id)) {
      db.profile.applications.unshift({
        id: crypto.randomUUID(),
        roleId: role.id,
        roleTitle: role.title,
        status: "submitted",
        submittedAt: new Date().toISOString(),
        rate: role.rate
      });
    }

    const intake = {
      id: crypto.randomUUID(),
      patientRef: `AN-PAT-${country.id.toUpperCase()}-DEMO`,
      countryId: country.id,
      needSummary: `${country.name} executive demo intake for queue, heat, and representative workflow`,
      riskLevel: country.risk === "High" || country.heat >= 38 ? "High" : "Routine",
      queueStatus: "Care plan generated",
      representativeStatus: "Connected",
      createdAt: new Date().toISOString()
    };
    db.profile.healthIntakes.unshift(intake);
    db.profile.representativeConnections += 1;
    const careResult = await runAi("careplan", country, route, db.profile);
    db.profile.carePlans.unshift({
      id: crypto.randomUUID(),
      intakeId: intake.id,
      patientRef: intake.patientRef,
      countryId: country.id,
      status: "active",
      text: careResult.text,
      provider: careResult.provider,
      createdAt: new Date().toISOString()
    });
    country.queue = "Care plan generated";

    const product = (db.products || [])[0];
    if (product) {
      const demoOrder = {
        id: crypto.randomUUID(),
        orderNumber: `AN-ORD-${String(db.profile.orders.length + 1).padStart(4, "0")}`,
        productId: product.id,
        product: product.name,
        countryId: product.countryId,
        routeId: route.id,
        checkpoint: db.profile.activeCheckpoint,
        checkpointIndex: 0,
        stage: "In transit",
        stageIndex: 2,
        buyerInterest: product.buyerInterest,
        total: product.price * 20,
        timeline: [
          { label: "In transit", checkpoint: db.profile.activeCheckpoint, createdAt: new Date().toISOString() },
          { label: "Packed", checkpoint: db.profile.activeCheckpoint, createdAt: new Date().toISOString() },
          { label: "Order created", checkpoint: db.profile.activeCheckpoint, createdAt: new Date().toISOString() }
        ],
        createdAt: new Date().toISOString()
      };
      db.profile.orders.push(demoOrder);
      addTradeEvent(db.profile, { type: "order.demo_run", label: `${demoOrder.orderNumber} created during executive demo run` });
    }

    for (const event of [
      ["learning-certificates", "Learning", "demo.learning_completed", `${course.title} learning path completed in demo run.`],
      ["workforce-hris", "Workforce", "demo.workforce_synced", "Candidate readiness, application, and mentor evidence synced in demo run."],
      ["health-telehealth", "Healthcare", "demo.health_case_opened", `${intake.patientRef} intake and care-plan evidence created in demo run.`],
      ["trade-market", "AgriTrade", "demo.trade_order_created", "Trade order and market evidence created in demo run."]
    ]) {
      logIntegration(db, { providerId: event[0], module: event[1], action: event[2], detail: event[3] });
    }

    for (const moduleName of ["Learning", "Workforce", "Healthcare", "AgriTrade"]) {
      addNotification(db.profile, {
        module: moduleName,
        providerId: moduleName === "Healthcare" ? "health-notifications" : moduleName === "Workforce" ? "workforce-notifications" : moduleName === "Learning" ? "learning-certificates" : "trade-logistics",
        channel: "executive-demo",
        message: `${moduleName} executive demo workflow completed.`,
        createdBy: user.name
      });
    }

    const copilot = await runAi("copilot", country, route, db.profile);
    recordAiRun(db, { type: "copilot", country, route, result: copilot, module: "AI" });
    recalcReadiness(db.profile);
    addActivity(db.profile, "Executive demo run completed across learning, workforce, health, trade, AI, notifications, and integrations.");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/demo/wow" && req.method === "POST") {
    if (!canUse(user, "admin")) return send(res, 403, { error: "Role does not allow investor demo runs" });
    const nigeria = db.countries.find(item => item.id === "nigeria") || db.countries[0];
    db.profile.activeCountryId = nigeria.id;
    db.profile.activeRouteId = nigeria.routeId;
    const { country, route } = activeContext(db);
    db.profile.activeCheckpoint = route.checkpoints[0];
    db.profile.routeStage = "Investor demo live";
    ensureLearningProfile(db.profile);
    ensureWorkforceProfile(db.profile);
    ensureHealthProfile(db.profile);
    ensureTradeProfile(db.profile);
    ensureAiProfile(db.profile);

    const course = db.courses.find(item => item.id === "telehealth-support") || db.courses[0];
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "completed",
        progress: 100,
        score: 92,
        activeModuleIndex: 0,
        completedModules: (course.modules || []).map((_, index) => index),
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString()
      };
      db.profile.enrollments.unshift(enrollment);
    } else {
      enrollment.status = "completed";
      enrollment.progress = 100;
      enrollment.score = Math.max(enrollment.score || 0, 92);
      enrollment.completedModules = (course.modules || []).map((_, index) => index);
      enrollment.completedAt = new Date().toISOString();
    }
    db.profile.activeCourseId = course.id;
    db.profile.quizScore = Math.max(db.profile.quizScore || 0, 92);
    if (!db.profile.completedCourses.includes(course.id)) db.profile.completedCourses.push(course.id);
    if (!db.profile.certificates.some(item => item.courseId === course.id)) {
      db.profile.certificates.push({
        id: crypto.randomUUID(),
        certificateNumber: `AN-CERT-${String(db.profile.certificates.length + 1).padStart(4, "0")}`,
        courseId: course.id,
        title: course.title,
        issuedAt: new Date().toISOString()
      });
    }
    for (const mode of ["caption", "visual", "low-bandwidth"]) {
      db.profile.learningAccommodations.unshift({
        id: crypto.randomUUID(),
        courseId: course.id,
        courseTitle: course.title,
        mode,
        title: mode === "caption" ? "Captioned lesson packet" : mode === "visual" ? "Audio guide and screen-reader outline" : "Offline low-bandwidth packet",
        language: "sw",
        supports: mode === "caption" ? ["live captions", "transcript", "relay handoff"] : mode === "visual" ? ["audio narration", "screen-reader outline", "large-print summary"] : ["SMS summary", "offline packet", "community aide checklist"],
        status: "ready",
        progressAtRequest: 100,
        createdAt: new Date().toISOString()
      });
    }
    db.profile.learningAccommodations = db.profile.learningAccommodations.slice(0, 20);
    db.profile.learningHours = Number((Number(db.profile.learningHours || 0) + 2).toFixed(1));
    db.profile.learningStreak += 3;
    db.profile.readiness = Math.max(db.profile.readiness || 0, 96);

    if (!db.profile.workforceBadges.includes("Profile Verified")) db.profile.workforceBadges.push("Profile Verified");
    if (!db.profile.workforceBadges.includes("Accessibility Support Ready")) db.profile.workforceBadges.push("Accessibility Support Ready");
    if (!db.profile.workforceBadges.includes("Mentor Matched")) db.profile.workforceBadges.push("Mentor Matched");
    db.profile.eligibility = "Eligible";
    db.profile.careerTrack = "Leadership Pathway";
    db.profile.learningPath = "Healthcare Access Workforce";
    db.profile.mentor = "Assigned";
    db.profile.candidateStage = "Shift Ready";
    db.profile.interviews = Math.max(db.profile.interviews || 0, 2);
    const role = db.roles.find(item => item.id === "health-rep") || db.roles[0];
    if (role && !db.profile.applications.some(item => item.roleId === role.id)) {
      db.profile.applications.unshift({
        id: crypto.randomUUID(),
        roleId: role.id,
        roleTitle: role.title,
        status: "submitted",
        submittedAt: new Date().toISOString(),
        rate: role.rate
      });
    }
    if (!(db.profile.shiftSchedule || []).some(item => item.demoShift)) {
      const shift = {
        id: crypto.randomUUID(),
        role: role?.title || "Accessible Health Representative",
        startsAt: new Date(Date.now() + 86400000).toISOString(),
        status: "scheduled",
        estimatedEarnings: role?.rate || 160,
        demoShift: true
      };
      db.profile.shiftSchedule.unshift(shift);
      db.profile.nextShift = new Date(shift.startsAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" });
      db.profile.earnings = Math.max(db.profile.earnings || 0, shift.estimatedEarnings);
    }

    const intake = {
      id: crypto.randomUUID(),
      patientRef: `AN-PAT-NGA-WOW`,
      countryId: country.id,
      needSummary: "Rural Nigeria accessible telehealth intake for hearing and visual impairment support",
      riskLevel: "Moderate",
      queueStatus: "Accessible telehealth plan ready",
      representativeStatus: "Caregiver notified",
      createdAt: new Date().toISOString()
    };
    db.profile.healthIntakes.unshift(intake);
    db.profile.representativeConnections += 1;
    db.profile.telehealthAccessibility.unshift(
      {
        id: crypto.randomUUID(),
        intakeId: intake.id,
        patientRef: intake.patientRef,
        countryId: country.id,
        title: "Accessible telehealth plan",
        status: "Access plan ready",
        language: "sw",
        supports: ["caption relay", "audio description", "large-print summary", "caregiver handoff", "low-bandwidth callback"],
        createdAt: new Date().toISOString()
      },
      {
        id: crypto.randomUUID(),
        intakeId: intake.id,
        patientRef: intake.patientRef,
        countryId: country.id,
        title: "Caption relay session",
        status: "Caption relay active",
        language: "sw",
        supports: ["live captions", "transcript", "SMS summary"],
        createdAt: new Date().toISOString()
      },
      {
        id: crypto.randomUUID(),
        intakeId: intake.id,
        patientRef: intake.patientRef,
        countryId: country.id,
        title: "Caregiver accessibility notification",
        status: "Caregiver notified",
        language: "sw",
        supports: ["trusted caregiver alert", "representative callback", "community aide checklist"],
        createdAt: new Date().toISOString()
      }
    );
    db.profile.telehealthAccessibility = db.profile.telehealthAccessibility.slice(0, 20);
    db.profile.safetyReviews.unshift({
      id: crypto.randomUUID(),
      countryId: country.id,
      riskLevel: country.risk,
      heatIndex: country.heat,
      dataQuality: 97,
      recommendation: "Proceed with human-supported accessible telehealth, caregiver handoff, and low-bandwidth callback.",
      createdAt: new Date().toISOString()
    });
    const careResult = await runAi("careplan", country, route, db.profile);
    db.profile.carePlans.unshift({
      id: crypto.randomUUID(),
      intakeId: intake.id,
      patientRef: intake.patientRef,
      countryId: country.id,
      status: "active",
      text: `${careResult.text} Accessibility addendum: use captions, audio description, caregiver confirmation, and SMS fallback.`,
      provider: careResult.provider,
      createdAt: new Date().toISOString()
    });
    country.queue = "Accessible telehealth plan ready";

    const product = (db.products || []).find(item => item.countryId === country.id) || (db.products || [])[0];
    if (product) {
      const order = {
        id: crypto.randomUUID(),
        orderNumber: `AN-ORD-${String(db.profile.orders.length + 1).padStart(4, "0")}`,
        productId: product.id,
        product: product.name,
        countryId: country.id,
        routeId: route.id,
        checkpoint: route.checkpoints[1] || route.checkpoints[0],
        checkpointIndex: 1,
        stage: "Quality check",
        stageIndex: 3,
        buyerInterest: Math.max(product.buyerInterest || 0, 88),
        total: product.price * 25,
        timeline: [
          { label: "Quality check", checkpoint: route.checkpoints[1] || route.checkpoints[0], createdAt: new Date().toISOString() },
          { label: "In transit", checkpoint: route.checkpoints[0], createdAt: new Date().toISOString() },
          { label: "Packed", checkpoint: route.checkpoints[0], createdAt: new Date().toISOString() },
          { label: "Order created", checkpoint: route.checkpoints[0], createdAt: new Date().toISOString() }
        ],
        createdAt: new Date().toISOString()
      };
      db.profile.orders.push(order);
      db.profile.activeCheckpoint = order.checkpoint;
      db.profile.routeStage = order.stage;
      addTradeEvent(db.profile, { type: "order.wow_demo", label: `${order.orderNumber} advanced to quality check during WOW investor demo` });
      db.profile.walletTransactions.unshift({
        id: crypto.randomUUID(),
        provider: "M-Pesa",
        amount: 450,
        type: "credit",
        status: "posted",
        createdAt: new Date().toISOString()
      });
      db.profile.wallet = Number((Number(db.profile.wallet || 0) + 450).toFixed(2));
    }

    const aiTypes = ["copilot", "tutor", "triage", "command", "route"];
    for (const type of aiTypes) {
      const result = await runAi(type, country, route, db.profile);
      recordAiRun(db, { type, country, route, result, module: type === "tutor" ? "Learning" : type === "triage" ? "Healthcare" : type === "route" ? "AgriTrade" : "AI" });
    }

    const demoEvents = [
      ["learning-certificates", "Learning", "wow.learning_accessible", "Accessible telehealth course completed with captions, audio guide, and offline packet."],
      ["workforce-hris", "Workforce", "wow.workforce_shift_ready", "Accessible health representative moved into shift-ready workforce state."],
      ["health-telehealth", "Healthcare", "wow.telehealth_accessible", `${intake.patientRef} accessible telehealth session prepared.`],
      ["health-notifications", "Healthcare", "wow.caregiver_notified", "Caregiver and community aide notification recorded."],
      ["health-ehr", "Healthcare", "wow.accessible_care_plan", "Accessible care plan synced for clinical review."],
      ["trade-market", "AgriTrade", "wow.trade_quality_check", "Nigeria product order advanced with payment and route evidence."],
      ["openai", "AI", "wow.ai_orchestration", "AI recommendations generated across learning, workforce, health, trade, and map intelligence."]
    ];
    for (const [providerId, module, action, detail] of demoEvents) {
      logIntegration(db, { providerId, module, action, detail });
    }

    for (const moduleName of ["Learning", "Workforce", "Healthcare", "AgriTrade", "AI"]) {
      addNotification(db.profile, {
        module: moduleName,
        providerId: moduleName === "Healthcare" ? "health-notifications" : moduleName === "Workforce" ? "workforce-notifications" : moduleName === "Learning" ? "learning-certificates" : moduleName === "AgriTrade" ? "trade-logistics" : "openai",
        channel: "wow-demo",
        message: `${moduleName} WOW demo evidence completed for rural Nigeria accessibility scenario.`,
        createdBy: user.name
      });
    }

    db.profile.demoMoments = [
      { title: "Accessible learner starts", detail: "Telehealth course completed with captions, audio guide, screen-reader outline, and offline packet.", evidence: "Learning accommodation + certificate", status: "done" },
      { title: "Training becomes work", detail: "Candidate is verified, matched to a health access role, assigned mentor support, and scheduled for a paid shift.", evidence: "HRIS + calendar + notification", status: "done" },
      { title: "Telehealth meets ADA needs", detail: "Patient receives caption relay, audio description, caregiver notification, and low-bandwidth callback support.", evidence: "Telehealth + EHR + notification", status: "done" },
      { title: "AI remains supervised", detail: "AI guidance is recorded with safety review, care plan, route intelligence, and human oversight.", evidence: "AI run + governance trail", status: "done" },
      { title: "Trade engine moves value", detail: "Nigeria product order advances through quality check with wallet and route evidence.", evidence: "Market + payment + logistics", status: "done" },
      { title: "Investor proof appears", detail: "Provider events, notifications, activity, map context, and profile state update across the whole platform.", evidence: "Audit-ready operating record", status: "done" }
    ];
    db.profile.demoScore = 100;
    recalcReadiness(db.profile);
    addActivity(db.profile, "WOW investor demo completed: rural Nigeria accessibility, learning, workforce, telehealth, trade, map, AI, notifications, and provider evidence are all active.");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/context" && (req.method === "PATCH" || req.method === "POST")) {
    const body = await readBody(req);
    const country = db.countries.find(item => item.id === body.countryId);
    if (!country) return send(res, 404, { error: "Country not found" });
    const route = db.routes.find(item => item.id === country.routeId);
    const current = db.users.find(item => item.id === user.id) || user;
    const nextLanguage = COUNTRY_LANGUAGE[country.id] || current.language || "en";
    db.profile.activeCountryId = country.id;
    db.profile.activeRouteId = route.id;
    db.profile.activeCheckpoint = route.checkpoints[0];
    current.country = country.name;
    current.language = nextLanguage;
    db.profile.accessibilityProfile = {
      ...(db.profile.accessibilityProfile || {}),
      language: nextLanguage
    };
    addActivity(db.profile, `Country context changed to ${country.name}; platform language changed to ${nextLanguage.toUpperCase()}.`);
    await writeDb(db);
    return send(res, 200, publicState(db, current));
  }

  if (url.pathname === "/api/user/language" && req.method === "POST") {
    const body = await readBody(req);
    const allowed = new Set(["en", "fr", "sw", "ar"]);
    if (!allowed.has(body.language)) return send(res, 400, { error: "Unsupported language" });
    const current = db.users.find(item => item.id === user.id);
    current.language = body.language;
    db.profile.accessibilityProfile = {
      ...(db.profile.accessibilityProfile || {}),
      language: body.language
    };
    addActivity(db.profile, `Learning language changed to ${body.language.toUpperCase()}.`);
    await writeDb(db);
    return send(res, 200, publicState(db, current));
  }

  if (url.pathname === "/api/learning/start" && req.method === "POST") {
    if (!canUse(user, "learning")) return send(res, 403, { error: "Role does not allow learning workflows" });
    const body = await readBody(req);
    const course = db.courses.find(item => item.id === body.courseId);
    if (!course) return send(res, 404, { error: "Course not found" });
    ensureLearningProfile(db.profile);
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "in_progress",
        progress: 25,
        score: 0,
        activeModuleIndex: 0,
        completedModules: [],
        startedAt: new Date().toISOString(),
        completedAt: null
      };
      db.profile.enrollments.unshift(enrollment);
    } else {
      enrollment.status = enrollment.status === "completed" ? "completed" : "in_progress";
      enrollment.progress = Math.max(enrollment.progress, 25);
      enrollment.activeModuleIndex = enrollment.activeModuleIndex || 0;
      enrollment.completedModules = enrollment.completedModules || [];
    }
    db.profile.activeCourseId = course.id;
    db.profile.learningStreak += 1;
    db.profile.learningHours = Number((db.profile.learningHours + 0.5).toFixed(1));
    db.profile.readiness = Math.min(100, db.profile.readiness + Math.ceil(course.readiness / 2));
    recalcReadiness(db.profile);
    logIntegration(db, {
      providerId: "learning-certificates",
      module: "Learning",
      action: "course.started",
      detail: `${course.title} enrollment recorded in the learning workspace.`,
      metadata: { courseId: course.id, enrollmentId: enrollment.id, progress: enrollment.progress }
    });
    addActivity(db.profile, `Started ${course.title}; learning progress is ${enrollment.progress}%.`);
    addWorkflowNote(db.profile, body.note, "Course note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/learning/lesson" && req.method === "POST") {
    if (!canUse(user, "learning")) return send(res, 403, { error: "Role does not allow learning workflows" });
    const body = await readBody(req);
    const course = db.courses.find(item => item.id === (body.courseId || db.profile.activeCourseId));
    if (!course) return send(res, 404, { error: "Course not found" });
    ensureLearningProfile(db.profile);
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "in_progress",
        progress: 25,
        score: 0,
        activeModuleIndex: 0,
        completedModules: [],
        startedAt: new Date().toISOString(),
        completedAt: null
      };
      db.profile.enrollments.unshift(enrollment);
    }
    const modules = course.modules || [];
    const selectedIndex = Number.isInteger(body.moduleIndex) ? body.moduleIndex : enrollment.activeModuleIndex || 0;
    const moduleIndex = Math.max(0, Math.min(selectedIndex, Math.max(0, modules.length - 1)));
    enrollment.activeModuleIndex = moduleIndex;
    enrollment.completedModules = enrollment.completedModules || [];
    if (!enrollment.completedModules.includes(moduleIndex)) enrollment.completedModules.push(moduleIndex);
    const completedCount = enrollment.completedModules.length;
    const moduleProgress = modules.length ? Math.round((completedCount / modules.length) * 65) : 35;
    enrollment.progress = Math.max(enrollment.progress || 25, Math.min(90, 25 + moduleProgress));
    if (completedCount >= modules.length && modules.length) enrollment.status = "ready_for_quiz";
    db.profile.activeCourseId = course.id;
    db.profile.learningStreak += 1;
    db.profile.learningHours = Number((db.profile.learningHours + 0.35).toFixed(1));
    db.profile.readiness = Math.min(100, db.profile.readiness + 2);
    recalcReadiness(db.profile);
    logIntegration(db, {
      providerId: "learning-certificates",
      module: "Learning",
      action: "lesson.completed",
      detail: `${modules[moduleIndex] || course.title} completed in ${course.title}.`,
      metadata: { courseId: course.id, enrollmentId: enrollment.id, moduleIndex, progress: enrollment.progress }
    });
    addActivity(db.profile, `Completed lesson "${modules[moduleIndex] || course.title}" in ${course.title}; progress is ${enrollment.progress}%.`);
    addWorkflowNote(db.profile, body.note, "Lesson note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/learning/quiz" && req.method === "POST") {
    if (!canUse(user, "learning")) return send(res, 403, { error: "Role does not allow learning workflows" });
    const body = await readBody(req);
    ensureLearningProfile(db.profile);
    const course = db.courses.find(item => item.id === db.profile.activeCourseId) || db.courses[0];
    let enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment) {
      enrollment = {
        id: crypto.randomUUID(),
        courseId: course.id,
        status: "in_progress",
        progress: 25,
        score: 0,
        activeModuleIndex: 0,
        completedModules: [],
        startedAt: new Date().toISOString(),
        completedAt: null
      };
      db.profile.enrollments.unshift(enrollment);
    }
    enrollment.progress = Math.min(100, enrollment.progress + 35);
    enrollment.score = Math.min(100, enrollment.score + 25);
    db.profile.quizScore = Math.max(db.profile.quizScore, enrollment.score);
    db.profile.learningHours = Number((db.profile.learningHours + 0.75).toFixed(1));
    db.profile.readiness = Math.min(100, db.profile.readiness + 6);
    recalcReadiness(db.profile);
    logIntegration(db, {
      providerId: "learning-certificates",
      module: "Learning",
      action: "quiz.completed",
      detail: `${course.title} quiz recorded with score ${enrollment.score}.`,
      metadata: { courseId: course.id, enrollmentId: enrollment.id, score: enrollment.score, progress: enrollment.progress }
    });
    addActivity(db.profile, `${course.title} quiz advanced to ${enrollment.score}; progress is ${enrollment.progress}%.`);
    addWorkflowNote(db.profile, body.note, "Quiz note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/learning/certificate" && req.method === "POST") {
    if (!canUse(user, "learning")) return send(res, 403, { error: "Role does not allow credential workflows" });
    const body = await readBody(req);
    ensureLearningProfile(db.profile);
    const course = db.courses.find(item => item.id === db.profile.activeCourseId) || db.courses[0];
    const enrollment = getEnrollment(db.profile, course.id);
    if (!enrollment || enrollment.score < 25) return send(res, 409, { error: "Complete a quiz first" });
    if (!db.profile.completedCourses.includes(course.id)) db.profile.completedCourses.push(course.id);
    enrollment.status = "completed";
    enrollment.progress = 100;
    enrollment.completedAt = new Date().toISOString();
    if (!db.profile.certificates.some(item => item.courseId === course.id)) {
      const certificate = {
        id: crypto.randomUUID(),
        certificateNumber: `AN-CERT-${String(db.profile.certificates.length + 1).padStart(4, "0")}`,
        courseId: course.id,
        title: course.title,
        issuedAt: new Date().toISOString()
      };
      db.profile.certificates.push(certificate);
      logIntegration(db, {
        providerId: "learning-certificates",
        module: "Learning",
        action: "certificate.issued",
        detail: `${certificate.certificateNumber} issued for ${course.title}.`,
        metadata: { courseId: course.id, certificateNumber: certificate.certificateNumber }
      });
    }
    db.profile.readiness = Math.min(100, db.profile.readiness + 10);
    db.profile.learningStreak += 1;
    recalcReadiness(db.profile);
    addActivity(db.profile, `Certificate issued for ${course.title}.`);
    addWorkflowNote(db.profile, body.note, "Certificate note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/learning/accessibility" && req.method === "POST") {
    if (!canUse(user, "learning")) return send(res, 403, { error: "Role does not allow learning workflows" });
    const body = await readBody(req);
    ensureLearningProfile(db.profile);
    const course = db.courses.find(item => item.id === (body.courseId || db.profile.activeCourseId)) || db.courses[0];
    const enrollment = course ? getEnrollment(db.profile, course.id) : null;
    const modeNames = {
      caption: "Captioned lesson packet",
      visual: "Audio guide and screen-reader outline",
      "low-bandwidth": "Offline low-bandwidth packet"
    };
    const mode = modeNames[body.mode] ? body.mode : "caption";
    const accommodation = {
      id: crypto.randomUUID(),
      courseId: course?.id || null,
      courseTitle: course?.title || "Accessible learning path",
      mode,
      title: modeNames[mode],
      language: db.profile.accessibilityProfile.language || user.language || "sw",
      supports: mode === "caption"
        ? ["live captions", "transcript", "sign-language handoff prompt"]
        : mode === "visual"
          ? ["audio narration", "screen-reader outline", "large-print summary"]
          : ["SMS summary", "download packet", "community aide checklist"],
      status: "ready",
      progressAtRequest: enrollment?.progress || 0,
      createdAt: new Date().toISOString()
    };
    db.profile.learningAccommodations.unshift(accommodation);
    db.profile.learningAccommodations = db.profile.learningAccommodations.slice(0, 20);
    db.profile.learningHours = Number((Number(db.profile.learningHours || 0) + 0.25).toFixed(2));
    db.profile.learningStreak += 1;
    logIntegration(db, {
      providerId: "learning-certificates",
      module: "Learning",
      action: "learning.accessibility_ready",
      detail: `${accommodation.title} prepared for ${accommodation.courseTitle}.`,
      metadata: { accommodationId: accommodation.id, courseId: accommodation.courseId, mode }
    });
    db.profile.aiActivity = `${accommodation.title} prepared for hearing and visual accessibility.`;
    addActivity(db.profile, db.profile.aiActivity);
    addWorkflowNote(db.profile, body.note, "Learning accessibility note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/workforce/action" && req.method === "POST") {
    if (!canUse(user, "workforce")) return send(res, 403, { error: "Role does not allow workforce workflows" });
    const body = await readBody(req);
    ensureWorkforceProfile(db.profile);
    if (body.type === "build-profile") {
      db.profile.candidateStage = db.profile.readiness >= 55 ? "Shortlist" : "Profile Ready";
      db.profile.readiness = Math.min(100, db.profile.readiness + 10);
      if (!db.profile.workforceBadges.includes("Profile Verified")) db.profile.workforceBadges.push("Profile Verified");
      logIntegration(db, {
        providerId: "workforce-hris",
        module: "Workforce",
        action: "profile.verified",
        detail: "Candidate profile verification synced to sandbox HRIS.",
        metadata: { readiness: db.profile.readiness, candidateStage: db.profile.candidateStage }
      });
      addActivity(db.profile, "Workforce profile verified with learning and certificate review.");
    } else if (body.type === "interview") {
      if (db.profile.readiness < 50) return send(res, 409, { error: "Reach 50% readiness first" });
      db.profile.interviews += 1;
      db.profile.candidateStage = "Interview";
      db.profile.lastInterviewAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      logIntegration(db, {
        providerId: "workforce-calendar",
        module: "Workforce",
        action: "interview.scheduled",
        detail: "Interview event recorded in sandbox calendar.",
        metadata: { startsAt: db.profile.lastInterviewAt }
      });
      logIntegration(db, {
        providerId: "workforce-notifications",
        module: "Workforce",
        action: "notification.sent",
        detail: "Interview notification recorded.",
        metadata: { channel: "sandbox" }
      });
      addActivity(db.profile, "Interview scheduled for tomorrow with workforce operations.");
    } else if (body.type === "mentor") {
      db.profile.mentor = "Assigned";
      db.profile.readiness = Math.min(100, db.profile.readiness + 5);
      db.profile.mentorNotes.unshift({ id: crypto.randomUUID(), note: "Mentor assigned to review readiness gaps and role fit.", createdAt: new Date().toISOString() });
      if (!db.profile.workforceBadges.includes("Mentor Matched")) db.profile.workforceBadges.push("Mentor Matched");
      logIntegration(db, {
        providerId: "workforce-hris",
        module: "Workforce",
        action: "mentor.assigned",
        detail: "Mentor assignment synced to sandbox HRIS.",
        metadata: { mentor: db.profile.mentor }
      });
      addActivity(db.profile, "Mentor assigned for role readiness coaching.");
    } else if (body.type === "shift") {
      if (db.profile.interviews < 1) return send(res, 409, { error: "Schedule an interview before starting a shift" });
      const shift = {
        id: crypto.randomUUID(),
        role: db.profile.applications[0]?.roleTitle || "Field Operations Agent",
        startsAt: new Date(Date.now() + 36 * 60 * 60 * 1000).toISOString(),
        status: "scheduled",
        estimatedEarnings: 64
      };
      db.profile.shiftSchedule.unshift(shift);
      db.profile.nextShift = `${shift.role} - ${new Date(shift.startsAt).toLocaleString("en-US", { weekday: "short", hour: "numeric", minute: "2-digit" })}`;
      db.profile.readiness = Math.min(100, db.profile.readiness + 6);
      db.profile.earnings += shift.estimatedEarnings;
      if (!db.profile.workforceBadges.includes("Shift Scheduled")) db.profile.workforceBadges.push("Shift Scheduled");
      logIntegration(db, {
        providerId: "workforce-calendar",
        module: "Workforce",
        action: "shift.scheduled",
        detail: `${shift.role} shift recorded in sandbox calendar.`,
        metadata: { shiftId: shift.id, startsAt: shift.startsAt }
      });
      logIntegration(db, {
        providerId: "workforce-shifts",
        module: "Workforce",
        action: "shift.assignment_created",
        detail: `${shift.role} shift assignment sent to workforce scheduler.`,
        metadata: {
          shiftId: shift.id,
          startsAt: shift.startsAt,
          endsAt: shift.endsAt,
          estimatedEarnings: shift.estimatedEarnings,
          candidateStage: db.profile.candidateStage
        }
      });
      logIntegration(db, {
        providerId: "workforce-notifications",
        module: "Workforce",
        action: "shift.notification_sent",
        detail: `${shift.role} shift notification sent to candidate channel.`,
        metadata: { shiftId: shift.id, channel: "candidate-workflow" }
      });
      addActivity(db.profile, `${shift.role} shift scheduled; estimated earnings ${shift.estimatedEarnings}.`);
    }
    recalcReadiness(db.profile);
    addWorkflowNote(db.profile, body.note, "Workforce note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/workforce/apply" && req.method === "POST") {
    if (!canUse(user, "workforce")) return send(res, 403, { error: "Role does not allow workforce applications" });
    const body = await readBody(req);
    const role = db.roles.find(item => item.id === body.roleId);
    if (!role) return send(res, 404, { error: "Role not found" });
    ensureWorkforceProfile(db.profile);
    const readiness = roleReadiness(db.profile, role);
    if (!readiness.eligible) {
      const certificateText = readiness.missingCertificates.length ? ` and certificate(s): ${readiness.missingCertificates.join(", ")}` : "";
      return send(res, 409, { error: `${role.title} needs ${readiness.missingReadiness}% more readiness${certificateText}` });
    }
    let application = db.profile.applications.find(item => item.roleId === role.id);
    if (!application) {
      application = {
        id: crypto.randomUUID(),
        roleId: role.id,
        roleTitle: role.title,
        status: "submitted",
        submittedAt: new Date().toISOString(),
        rate: role.rate
      };
      db.profile.applications.unshift(application);
    } else {
      application.status = application.status || "submitted";
      application.lastReviewedAt = new Date().toISOString();
    }
    logIntegration(db, {
      providerId: "workforce-hris",
      module: "Workforce",
      action: "application.submitted",
      detail: `${role.title} application synced to sandbox HRIS.`,
      metadata: { applicationId: application.id, roleId: role.id }
    });
    db.profile.placements = db.profile.applications.length;
    db.profile.interviews = Math.max(db.profile.interviews, 1);
    db.profile.candidateStage = db.profile.placements > 1 ? "Placement Pool" : "Interview";
    db.profile.earnings = Math.max(db.profile.earnings, 180 + role.rate);
    addActivity(db.profile, `Applied to ${role.title}.`);
    addWorkflowNote(db.profile, body.note, "Application note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/health/action" && req.method === "POST") {
    if (!canUse(user, "health")) return send(res, 403, { error: "Role does not allow healthcare workflows" });
    const body = await readBody(req);
    const { country, route } = activeContext(db);
    ensureHealthProfile(db.profile);
    if (body.type === "intake") {
      const urgency = String(body.urgency || "").trim();
      const accessibilityNeeds = String(body.accessibilityNeeds || "").trim();
      const preferredLanguage = String(body.preferredLanguage || db.profile.accessibilityProfile.language || user.language || "en").trim();
      const contactMethod = String(body.contactMethod || "Low-bandwidth callback").trim();
      const caregiverName = String(body.caregiverName || "Community accessibility aide").trim();
      const needSummary = String(body.needSummary || `${country.name} intake for heat, queue, and field access review`).trim();
      const patientName = String(body.patientName || "Community patient").trim();
      const intake = {
        id: crypto.randomUUID(),
        patientRef: `AN-PAT-${country.id.toUpperCase()}-${String(db.profile.healthIntakes.length + 1).padStart(3, "0")}`,
        patientName,
        countryId: country.id,
        needSummary,
        riskLevel: urgency || (country.risk === "High" || country.heat >= 38 ? "High" : "Routine"),
        queueStatus: "Intake session in progress",
        representativeStatus: "Not connected",
        preferredLanguage,
        accessibilityNeeds,
        contactMethod,
        caregiverName,
        assistiveSupports: accessibilityNeeds
          ? accessibilityNeeds.split(",").map(item => item.trim()).filter(Boolean)
          : ["caption relay", "audio narration", "large-print summary", "caregiver handoff"],
        routeContext: {
          routeId: route.id,
          routeName: route.name,
          checkpoint: db.profile.activeCheckpoint
        },
        createdAt: new Date().toISOString()
      };
      db.profile.healthIntakes.unshift(intake);
      logIntegration(db, {
        providerId: "health-telehealth",
        module: "Healthcare",
        action: "intake.created",
        detail: `${intake.patientRef} telehealth intake recorded for ${patientName}.`,
        metadata: {
          intakeId: intake.id,
          countryId: country.id,
          patientName,
          preferredLanguage,
          contactMethod,
          accessibilityNeeds,
          caregiverName
        }
      });
      country.patients += 25;
      country.queue = "Intake session in progress";
      db.profile.aiActivity = `Telehealth intake ${intake.patientRef} opened for ${country.name}: ${needSummary}.`;
    } else if (body.type === "representative") {
      const intake = db.profile.healthIntakes[0];
      if (intake) {
        intake.queueStatus = "Representative connected";
        intake.representativeStatus = "Connected";
      }
      db.profile.representativeConnections += 1;
      logIntegration(db, {
        providerId: "health-notifications",
        module: "Healthcare",
        action: "representative.connected",
        detail: "Representative escalation notification recorded.",
        metadata: { intakeId: intake?.id || null }
      });
      country.queue = "Representative connected";
      db.profile.aiActivity = `Representative connected for ${country.name}.`;
    } else if (body.type === "safety") {
      const review = {
        id: crypto.randomUUID(),
        countryId: country.id,
        riskLevel: country.risk,
        heatIndex: country.heat,
        dataQuality: Math.min(99, country.quality + 1),
        recommendation: `Review ${country.name} heat exposure, queue pressure, and representative coverage before autonomous guidance.`,
        createdAt: new Date().toISOString()
      };
      db.profile.safetyReviews.unshift(review);
      logIntegration(db, {
        providerId: "health-ehr",
        module: "Healthcare",
        action: "safety.review",
        detail: `${country.name} safety review recorded for care audit.`,
        metadata: { reviewId: review.id, countryId: country.id }
      });
      country.quality = Math.min(99, country.quality + 1);
      country.safety = Math.max(1, Number((country.safety - 0.1).toFixed(1)));
      db.profile.aiActivity = `Safety review run for ${country.name}.`;
    } else if (body.type === "inspector") {
      const result = await runAi("inspector", country, route, db.profile);
      recordAiRun(db, { type: "inspector", country, route, result, module: "Healthcare" });
    } else if (body.type === "careplan") {
      const result = await runAi("careplan", country, route, db.profile);
      const intake = db.profile.healthIntakes[0] || {
        id: crypto.randomUUID(),
        patientRef: `AN-PAT-${country.id.toUpperCase()}-AUTO`,
        countryId: country.id,
        riskLevel: country.risk,
        needSummary: `${country.name} care plan review`,
        createdAt: new Date().toISOString()
      };
      if (!db.profile.healthIntakes.find(item => item.id === intake.id)) db.profile.healthIntakes.unshift(intake);
      const carePlan = {
        id: crypto.randomUUID(),
        intakeId: intake.id,
        patientRef: intake.patientRef,
        countryId: country.id,
        status: "active",
        text: result.text,
        provider: result.provider,
        createdAt: new Date().toISOString()
      };
      db.profile.carePlans.unshift(carePlan);
      logIntegration(db, {
        providerId: "health-ehr",
        module: "Healthcare",
        action: "care_plan.synced",
        detail: `${carePlan.patientRef} care plan synced to sandbox EHR.`,
        metadata: { carePlanId: carePlan.id, intakeId: intake.id }
      });
      intake.queueStatus = "Care plan generated";
      recordAiRun(db, { type: "careplan", country, route, result, module: "Healthcare" });
    } else if (["accessibility", "caption", "caregiver"].includes(body.type)) {
      const intake = db.profile.healthIntakes[0] || {
        id: crypto.randomUUID(),
        patientRef: `AN-PAT-${country.id.toUpperCase()}-ACCESS`,
        countryId: country.id,
        riskLevel: country.risk,
        needSummary: `${country.name} accessible telehealth review`,
        queueStatus: "Accessibility review",
        representativeStatus: "Accessibility aide pending",
        createdAt: new Date().toISOString()
      };
      if (!db.profile.healthIntakes.find(item => item.id === intake.id)) db.profile.healthIntakes.unshift(intake);
      const actions = {
        accessibility: {
          title: "Accessible telehealth plan",
          status: "Access plan ready",
          supports: ["caption relay", "audio description", "large-print summary", "caregiver handoff", "low-bandwidth callback"],
          providerId: "health-ehr",
          action: "telehealth.accessibility_plan"
        },
        caption: {
          title: "Caption relay session",
          status: "Caption relay active",
          supports: ["live captions", "transcript", "SMS summary"],
          providerId: "health-telehealth",
          action: "telehealth.caption_relay"
        },
        caregiver: {
          title: "Caregiver accessibility notification",
          status: "Caregiver notified",
          supports: ["trusted caregiver alert", "representative callback", "community aide checklist"],
          providerId: "health-notifications",
          action: "telehealth.caregiver_notified"
        }
      };
      const selected = actions[body.type];
      const record = {
        id: crypto.randomUUID(),
        intakeId: intake.id,
        patientRef: intake.patientRef,
        countryId: country.id,
        title: selected.title,
        status: selected.status,
        language: db.profile.accessibilityProfile.language || user.language || "sw",
        supports: selected.supports,
        createdAt: new Date().toISOString()
      };
      db.profile.telehealthAccessibility.unshift(record);
      db.profile.telehealthAccessibility = db.profile.telehealthAccessibility.slice(0, 20);
      intake.queueStatus = selected.status;
      intake.representativeStatus = body.type === "caregiver" ? "Caregiver notified" : "Accessibility prepared";
      country.queue = selected.status;
      db.profile.aiActivity = `${selected.title} prepared for ${intake.patientRef}.`;
      logIntegration(db, {
        providerId: selected.providerId,
        module: "Healthcare",
        action: selected.action,
        detail: `${selected.title} recorded for ${intake.patientRef}.`,
        metadata: { accessibilityId: record.id, intakeId: intake.id, countryId: country.id }
      });
    }
    addActivity(db.profile, db.profile.aiActivity);
    addWorkflowNote(db.profile, body.note, "Health note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/trade/order" && req.method === "POST") {
    if (!canUse(user, "trade")) return send(res, 403, { error: "Role does not allow trade workflows" });
    const body = await readBody(req);
    ensureTradeProfile(db.profile);
    const product = (db.products || []).find(item => item.id === body.productId) || (db.products || []).find(item => item.name === body.product);
    const { country, route } = routeByProduct(db, product?.id || body.product || "");
    const checkpoint = route.checkpoints[0];
    const order = {
      id: crypto.randomUUID(),
      orderNumber: `AN-ORD-${String(db.profile.orders.length + 1).padStart(4, "0")}`,
      productId: product?.id || null,
      product: product?.name || body.product || "AgriNexus product",
      countryId: country.id,
      routeId: route.id,
      checkpoint,
      checkpointIndex: 0,
      stage: "Packed",
      stageIndex: 1,
      buyerInterest: product?.buyerInterest || 50,
      total: product ? product.price * 20 : 1200,
      timeline: [
        { label: "Order created", checkpoint, createdAt: new Date().toISOString() },
        { label: "Packed", checkpoint, createdAt: new Date().toISOString() }
      ],
      createdAt: new Date().toISOString()
    };
    db.profile.orders.push(order);
    db.profile.activeCountryId = country.id;
    db.profile.activeRouteId = route.id;
    db.profile.activeCheckpoint = order.checkpoint;
    db.profile.routeStage = order.stage;
    addTradeEvent(db.profile, { type: "order.created", label: `${order.orderNumber} created for ${order.product}` });
    logIntegration(db, {
      providerId: "trade-market",
      module: "AgriTrade",
      action: "order.created",
      detail: `${order.orderNumber} created with ${order.buyerInterest}% buyer interest.`,
      metadata: { orderId: order.id, productId: order.productId }
    });
    addActivity(db.profile, `Order created for ${order.product}.`);
    addWorkflowNote(db.profile, body.note, "Order note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/trade/advance" && req.method === "POST") {
    if (!canUse(user, "trade")) return send(res, 403, { error: "Role does not allow trade workflows" });
    const body = await readBody(req);
    ensureTradeProfile(db.profile);
    const order = db.profile.orders[db.profile.orders.length - 1];
    if (!order) return send(res, 409, { error: "Create an order first" });
    const route = db.routes.find(item => item.id === order.routeId) || activeRoute();
    const stages = ["Order created", "Packed", "In transit", "Quality check", "Delivered"];
    order.stageIndex = Math.min(stages.length - 1, (order.stageIndex || 0) + 1);
    order.stage = stages[order.stageIndex];
    order.checkpointIndex = Math.min(route.checkpoints.length - 1, (order.checkpointIndex || 0) + 1);
    order.checkpoint = route.checkpoints[order.checkpointIndex];
    order.timeline.unshift({ label: order.stage, checkpoint: order.checkpoint, createdAt: new Date().toISOString() });
    db.profile.routeStage = order.stage;
    db.profile.activeCheckpoint = order.checkpoint;
    addTradeEvent(db.profile, { type: "order.advanced", label: `${order.orderNumber} advanced to ${order.stage} at ${order.checkpoint}` });
    logIntegration(db, {
      providerId: "trade-logistics",
      module: "AgriTrade",
      action: "checkpoint.updated",
      detail: `${order.orderNumber} moved to ${order.checkpoint}.`,
      metadata: { orderId: order.id, stage: order.stage, checkpoint: order.checkpoint }
    });
    addActivity(db.profile, `Order advanced to ${db.profile.routeStage}.`);
    addWorkflowNote(db.profile, body.note, "Logistics note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/trade/wallet" && req.method === "POST") {
    if (!canUse(user, "trade")) return send(res, 403, { error: "Role does not allow wallet workflows" });
    const body = await readBody(req);
    ensureTradeProfile(db.profile);
    const tx = {
      id: crypto.randomUUID(),
      provider: body.provider || "Wallet",
      amount: Number(body.amount || 0),
      type: Number(body.amount || 0) >= 0 ? "credit" : "debit",
      status: "posted",
      createdAt: new Date().toISOString()
    };
    db.profile.wallet += tx.amount;
    db.profile.walletTransactions.unshift(tx);
    addTradeEvent(db.profile, { type: "wallet.transaction", label: `${tx.provider} ${tx.type} posted for $${Math.abs(tx.amount)}` });
    logIntegration(db, {
      providerId: "trade-payments",
      module: "AgriTrade",
      action: "wallet.transaction",
      detail: `${tx.provider} ${tx.type} posted.`,
      metadata: { transactionId: tx.id, amount: tx.amount }
    });
    addActivity(db.profile, `${tx.provider} payment posted: $${tx.amount}.`);
    addWorkflowNote(db.profile, body.note, "Payment note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/ai/run" && req.method === "POST") {
    if (!canUse(user, "ai")) return send(res, 403, { error: "Role does not allow AI workflows" });
    const body = await readBody(req);
    const { country, route } = activeContext(db);
    const type = body.type || "command";
    const result = await runAi(type, country, route, db.profile);
    recordAiRun(db, { type, country, route, result, module: body.module || aiModuleForType(type, "AI") });
    addActivity(db.profile, db.profile.aiActivity);
    addWorkflowNote(db.profile, body.note, "AI note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/ai/review" && req.method === "POST") {
    if (!canUse(user, "governance")) return send(res, 403, { error: "Role does not allow AI review" });
    const body = await readBody(req);
    ensureAiProfile(db.profile);
    const run = db.profile.aiRuns.find(item => item.id === body.runId) || db.profile.aiRuns[0];
    if (!run) return send(res, 404, { error: "AI run not found" });
    run.reviewStatus = body.decision === "reject" ? "rejected" : "approved";
    run.reviewedBy = user.name;
    run.reviewedAt = new Date().toISOString();
    run.reviewNote = String(body.note || "").trim();
    logIntegration(db, {
      providerId: "openai",
      module: "AI",
      action: "ai.reviewed",
      detail: `${run.type} AI run ${run.reviewStatus} by ${user.name}.`,
      metadata: { runId: run.id, decision: run.reviewStatus }
    });
    addActivity(db.profile, `${run.type} AI run ${run.reviewStatus} by ${user.name}.`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/agent/plan" && req.method === "POST") {
    if (!canUse(user, "ai")) return send(res, 403, { error: "Role does not allow agent planning" });
    const body = await readBody(req);
    ensureAiProfile(db.profile);
    const goal = String(body.goal || "Create an AgriNexus cross-module plan.").trim();
    const plan = buildAgentPlan(db, goal, user);
    db.profile.agentPlans.unshift(plan);
    db.profile.agentPlans = db.profile.agentPlans.slice(0, 12);
    logIntegration(db, {
      providerId: "openai",
      module: "AI",
      action: "agent.plan_created",
      detail: `Agent plan created with ${plan.steps.length} tool steps.`,
      metadata: { planId: plan.id, goal }
    });
    addActivity(db.profile, `Agent plan created: ${goal}`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/agent/execute" && req.method === "POST") {
    if (!canUse(user, "ai")) return send(res, 403, { error: "Role does not allow agent execution" });
    const body = await readBody(req);
    ensureAiProfile(db.profile);
    const plan = db.profile.agentPlans.find(item => item.id === body.planId) || db.profile.agentPlans[0];
    if (!plan) return send(res, 404, { error: "Agent plan not found" });
    const approved = body.approved !== false;
    if (!approved) return send(res, 409, { error: "Agent execution requires operator approval." });
    plan.status = "executing";
    plan.approvedBy = user.email;
    plan.approvedAt = new Date().toISOString();
    plan.executedBy = user.email;
    plan.executedAt = new Date().toISOString();
    const executedSteps = [];
    for (const step of plan.steps) {
      executedSteps.push(await executeAgentStepWithRetry(db, user, step, 2));
    }
    plan.steps = executedSteps;
    const failedSteps = executedSteps.filter(step => step.status === "failed");
    plan.status = failedSteps.length ? "needs-review" : "executed";
    const execution = {
      id: crypto.randomUUID(),
      planId: plan.id,
      goal: plan.goal,
      status: failedSteps.length ? "needs-review" : "completed",
      summary: failedSteps.length
        ? `Agent executed ${executedSteps.length - failedSteps.length}/${executedSteps.length} supervised steps; ${failedSteps.length} need operator review.`
        : `Agent autonomously executed ${executedSteps.length} supervised steps across learning, workforce, health, trade, maps, and AI.`,
      steps: executedSteps.map(step => ({ module: step.module, tool: step.tool, action: step.action, status: step.status, attempts: step.attempts, result: step.result, error: step.error })),
      createdAt: new Date().toISOString()
    };
    db.profile.agentExecutions.unshift(execution);
    db.profile.agentExecutions = db.profile.agentExecutions.slice(0, 20);
    db.profile.agentMemory = {
      lastPlanId: plan.id,
      lastExecutionId: execution.id,
      lastGoal: plan.goal,
      lastStatus: execution.status,
      lastSummary: execution.summary,
      updatedAt: new Date().toISOString()
    };
    addActivity(db.profile, execution.summary);
    addWorkflowNote(db.profile, body.note, "Agent note");
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  if (url.pathname === "/api/notifications/send" && req.method === "POST") {
    if (!canUse(user, "notifications")) return send(res, 403, { error: "Role does not allow notifications" });
    const body = await readBody(req);
    const moduleName = String(body.module || "Platform");
    const providerByModule = {
      Learning: "learning-certificates",
      Workforce: "workforce-notifications",
      Healthcare: "health-notifications",
      AgriTrade: "trade-logistics",
      AI: "openai",
      Platform: "openai"
    };
    const providerId = providerByModule[moduleName] || "openai";
    const message = String(body.message || `${moduleName} workflow notification sent.`).trim();
    addNotification(db.profile, { module: moduleName, providerId, channel: body.channel || "workflow", message, createdBy: user.name });
    logIntegration(db, {
      providerId,
      module: moduleName,
      action: "notification.sent",
      detail: message,
      metadata: { channel: body.channel || "workflow", createdBy: user.name }
    });
    addActivity(db.profile, `${moduleName} notification sent: ${message}`);
    await writeDb(db);
    return send(res, 200, publicState(db, user));
  }

  return send(res, 404, { error: "API route not found" });
}

function serveStatic(req, res, url) {
  let filePath = url.pathname === "/" ? path.join(PUBLIC, "index.html") : path.join(PUBLIC, decodeURIComponent(url.pathname));
  if (!filePath.startsWith(PUBLIC)) return send(res, 403, "Forbidden");
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, "Not found");
    res.writeHead(200, { "content-type": mime[path.extname(filePath)] || "application/octet-stream" });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  try {
    if (url.pathname.startsWith("/api/")) return await api(req, res, url);
    return serveStatic(req, res, url);
  } catch (error) {
    return send(res, 500, { error: error.message || "Server error" });
  }
});

server.on("error", error => {
  console.error(`AgriNexus server failed: ${error.message}`);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log(`AgriNexus running at http://${HOST}:${PORT}`);
});
