const assert = require("assert");
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const testPort = process.env.AGRINEXUS_TEST_PORT || "4373";
const base = process.env.AGRINEXUS_URL || `http://localhost:${testPort}`;
const dbPath = path.join(__dirname, "..", "db.json");
const dbSnapshot = fs.readFileSync(dbPath, "utf8");
let cookie = "";

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForServer() {
  for (let i = 0; i < 40; i += 1) {
    try {
      await fetch(`${base}/`);
      return;
    } catch {
      await wait(150);
    }
  }
  throw new Error("Server did not become reachable");
}

async function call(path, body) {
  const res = await fetch(`${base}${path}`, {
    method: body ? "POST" : "GET",
    headers: { "content-type": "application/json", cookie },
    body: body ? JSON.stringify(body) : undefined
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie) cookie = setCookie.split(";")[0];
  const json = await res.json();
  if (!res.ok) throw new Error(`${path}: ${json.error || res.statusText}`);
  return json;
}

(async () => {
  const server = spawn(process.execPath, ["server.js"], {
    cwd: `${__dirname}/..`,
    env: { ...process.env, PORT: testPort },
    stdio: "ignore",
    windowsHide: true
  });
  await waitForServer();
  const login = await call("/api/login", { email: "demo@agrinexus.org", password: "Prototype2026!" });
  assert(login.user.email === "demo@agrinexus.org");
  assert(login.providers.length >= 8);
  assert(login.admin.modules.length >= 6);
  assert(login.admin.readiness.total >= 12);
  assert(login.admin.readiness.moduleReadiness.length >= 6);
  assert(login.admin.readiness.status === "local-optimized" || login.admin.readiness.status === "production-ready");
  const language = await call("/api/user/language", { language: "fr" });
  assert(language.user.language === "fr");
  assert(language.profile.accessibilityProfile.language === "fr");
  const kenyaContext = await call("/api/context", { countryId: "kenya" });
  assert(kenyaContext.profile.activeCountryId === "kenya");
  assert(kenyaContext.user.language === "sw");
  assert(kenyaContext.profile.accessibilityProfile.language === "sw");
  const egyptContext = await call("/api/context", { countryId: "egypt" });
  assert(egyptContext.profile.activeCountryId === "egypt");
  assert(egyptContext.user.language === "ar");
  assert(egyptContext.profile.accessibilityProfile.language === "ar");
  const drcContext = await call("/api/context", { countryId: "drc" });
  assert(drcContext.profile.activeCountryId === "drc");
  assert(drcContext.user.language === "fr");
  assert(drcContext.profile.accessibilityProfile.language === "fr");
  const nigeriaContext = await call("/api/context", { countryId: "nigeria" });
  assert(nigeriaContext.profile.activeCountryId === "nigeria");
  assert(nigeriaContext.user.language === "en");
  assert(nigeriaContext.profile.accessibilityProfile.language === "en");
  const englishLanguage = await call("/api/user/language", { language: "en" });
  assert(englishLanguage.user.language === "en");
  assert(englishLanguage.profile.accessibilityProfile.language === "en");
  const started = await call("/api/learning/start", { courseId: "digital-foundations" });
  assert(started.profile.readiness >= 36);
  assert(started.profile.enrollments.length >= 1);
  assert(started.profile.enrollments[0].progress >= 25);
  assert(started.profile.integrationEvents.some(event => event.action === "course.started"));
  const lesson = await call("/api/learning/lesson", { courseId: "digital-foundations", moduleIndex: 0 });
  const lessonEnrollment = lesson.profile.enrollments.find(item => item.courseId === "digital-foundations");
  assert(lessonEnrollment.completedModules.includes(0));
  assert(lessonEnrollment.progress >= 45);
  assert(lesson.profile.integrationEvents.some(event => event.action === "lesson.completed"));
  const quiz = await call("/api/learning/quiz", {});
  assert(quiz.profile.quizScore >= 25);
  assert(quiz.profile.integrationEvents.some(event => event.action === "quiz.completed"));
  const cert = await call("/api/learning/certificate", {});
  assert(cert.profile.certificates.length >= 1);
  assert(cert.profile.completedCourses.includes("digital-foundations"));
  assert(cert.profile.integrationEvents.some(event => event.action === "certificate.issued"));
  const learningAccess = await call("/api/learning/accessibility", { courseId: "digital-foundations", mode: "caption" });
  assert(learningAccess.profile.learningAccommodations.length >= 1);
  assert(learningAccess.profile.integrationEvents.some(event => event.action === "learning.accessibility_ready"));
  const built = await call("/api/workforce/action", { type: "build-profile" });
  assert(built.profile.workforceBadges.includes("Profile Verified"));
  assert(built.profile.integrationEvents.some(event => event.action === "profile.verified"));
  const applied = await call("/api/workforce/apply", { roleId: "field-agent" });
  assert(applied.profile.applications.length >= 1);
  assert(applied.profile.integrationEvents.some(event => event.action === "application.submitted"));
  const interview = await call("/api/workforce/action", { type: "interview" });
  assert(interview.profile.interviews >= 1);
  assert(interview.profile.integrationEvents.some(event => event.action === "interview.scheduled"));
  assert(interview.profile.integrationEvents.some(event => event.action === "notification.sent"));
  const mentor = await call("/api/workforce/action", { type: "mentor" });
  assert(mentor.profile.mentor === "Assigned");
  assert(mentor.profile.integrationEvents.some(event => event.action === "mentor.assigned"));
  const shift = await call("/api/workforce/action", { type: "shift" });
  assert(shift.profile.shiftSchedule.length >= 1);
  assert(shift.profile.integrationEvents.some(event => event.action === "shift.scheduled"));
  const intake = await call("/api/health/action", {
    type: "intake",
    patientName: "Amina Okafor",
    needSummary: "Hearing-impaired patient needs heat exposure review and low-bandwidth follow-up",
    urgency: "Priority",
    preferredLanguage: "en",
    accessibilityNeeds: "Captions, audio narration, caregiver handoff",
    contactMethod: "Low-bandwidth callback",
    caregiverName: "Community accessibility aide"
  });
  assert(intake.profile.healthIntakes.length >= 1);
  assert(intake.profile.healthIntakes[0].patientName === "Amina Okafor");
  assert(intake.profile.healthIntakes[0].accessibilityNeeds.includes("Captions"));
  assert(intake.profile.healthIntakes[0].contactMethod === "Low-bandwidth callback");
  assert(intake.profile.integrationEvents.some(event => event.action === "intake.created"));
  const representative = await call("/api/health/action", { type: "representative" });
  assert(representative.profile.representativeConnections >= 1);
  assert(representative.profile.integrationEvents.some(event => event.action === "representative.connected"));
  const safety = await call("/api/health/action", { type: "safety" });
  assert(safety.profile.safetyReviews.length >= 1);
  assert(safety.profile.integrationEvents.some(event => event.action === "safety.review"));
  const inspector = await call("/api/health/action", { type: "inspector" });
  assert(inspector.profile.aiRuns.some(run => run.type === "inspector"));
  assert(inspector.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "Healthcare"));
  const carePlan = await call("/api/health/action", { type: "careplan" });
  assert(carePlan.profile.carePlans.length >= 1);
  assert(carePlan.profile.integrationEvents.some(event => event.action === "care_plan.synced"));
  assert(carePlan.profile.aiRuns.some(run => run.type === "careplan"));
  assert(carePlan.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "Healthcare"));
  const accessPlan = await call("/api/health/action", { type: "accessibility" });
  assert(accessPlan.profile.telehealthAccessibility.length >= 1);
  assert(accessPlan.profile.integrationEvents.some(event => event.action === "telehealth.accessibility_plan"));
  const captionRelay = await call("/api/health/action", { type: "caption" });
  assert(captionRelay.profile.integrationEvents.some(event => event.action === "telehealth.caption_relay"));
  const caregiverNotice = await call("/api/health/action", { type: "caregiver" });
  assert(caregiverNotice.profile.integrationEvents.some(event => event.action === "telehealth.caregiver_notified"));
  const providerTest = await call("/api/integrations/test", { providerId: "openai" });
  assert(providerTest.profile.integrationEvents.some(event => event.action === "provider.test"));
  const learningModuleTest = await call("/api/integrations/test-module", { module: "Learning" });
  assert(learningModuleTest.profile.integrationEvents.some(event => event.action === "provider.test_module" && event.module === "Learning"));
  const workforceModuleTest = await call("/api/integrations/test-module", { module: "Workforce" });
  assert(workforceModuleTest.profile.integrationEvents.some(event => event.action === "provider.test_module" && event.module === "Workforce"));
  const healthModuleTest = await call("/api/integrations/test-module", { module: "Healthcare" });
  assert(healthModuleTest.profile.integrationEvents.some(event => event.action === "provider.test_module" && event.module === "Healthcare"));
  const providerTestAll = await call("/api/integrations/test-all", {});
  assert(providerTestAll.profile.integrationEvents.some(event => event.action === "provider.test_all"));
  const admin = await call("/api/admin/health-check", {});
  assert(admin.admin.audit.length >= 1);
  assert(admin.profile.integrationEvents.some(event => event.action === "admin.health_check"));
  const order = await call("/api/trade/order", { productId: "avocado-ke" });
  assert(order.profile.orders.length >= 1);
  assert(order.profile.tradeEvents.some(event => event.type === "order.created"));
  const advanced = await call("/api/trade/advance", {});
  assert(advanced.profile.orders[advanced.profile.orders.length - 1].timeline.length >= 3);
  const wallet = await call("/api/trade/wallet", { provider: "M-Pesa", amount: 120 });
  assert(wallet.profile.walletTransactions.length >= 1);
  assert(wallet.profile.integrationEvents.some(event => event.action === "wallet.transaction"));
  const ai = await call("/api/ai/run", { type: "command" });
  assert(ai.profile.aiActivity.length > 20);
  assert(ai.profile.aiRuns.length >= 1);
  assert(ai.profile.aiRuns[0].type === "command");
  assert(ai.profile.mapInsights.length >= 1);
  assert(ai.profile.integrationEvents.some(event => event.action === "ai.run"));
  const tutorAi = await call("/api/ai/run", { type: "tutor" });
  assert(tutorAi.profile.aiRuns[0].type === "tutor");
  assert(tutorAi.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "Learning"));
  const workforceAi = await call("/api/ai/run", { type: "workforce-coach" });
  assert(workforceAi.profile.aiRuns[0].type === "workforce-coach");
  assert(workforceAi.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "Workforce"));
  const triageAi = await call("/api/ai/run", { type: "triage" });
  assert(triageAi.profile.aiRuns[0].type === "triage");
  assert(triageAi.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "Healthcare"));
  const tradeAi = await call("/api/ai/run", { type: "trade-advisor" });
  assert(tradeAi.profile.aiRuns[0].type === "trade-advisor");
  assert(tradeAi.profile.integrationEvents.some(event => event.action === "ai.run" && event.module === "AgriTrade"));
  const copilotAi = await call("/api/ai/run", { type: "copilot" });
  assert(copilotAi.profile.aiRuns[0].type === "copilot");
  assert(copilotAi.profile.aiRuns[0].reviewStatus === "pending-human-review");
  const reviewedAi = await call("/api/ai/review", { runId: copilotAi.profile.aiRuns[0].id, decision: "approve", note: "Smoke review" });
  assert(reviewedAi.profile.aiRuns[0].reviewStatus === "approved");
  assert(reviewedAi.profile.integrationEvents.some(event => event.action === "ai.reviewed"));
  const agentPlan = await call("/api/agent/plan", { goal: "Move a rural learner through training, workforce, telehealth, trade, maps, and AI evidence." });
  assert(agentPlan.profile.agentPlans.length >= 1);
  assert(agentPlan.profile.agentPlans[0].steps.length >= 6);
  assert(agentPlan.profile.integrationEvents.some(event => event.action === "agent.plan_created"));
  const agentExecution = await call("/api/agent/execute", { planId: agentPlan.profile.agentPlans[0].id });
  assert(agentExecution.profile.agentExecutions.length >= 1);
  assert(agentExecution.profile.agentPlans[0].status === "executed");
  assert(agentExecution.profile.agentExecutions[0].status === "completed");
  assert(agentExecution.profile.agentExecutions[0].steps.every(step => step.status === "executed"));
  assert(agentExecution.profile.agentMemory.lastStatus === "completed");
  assert(agentExecution.profile.integrationEvents.some(event => event.action === "agent.ai.copilot"));
  assert(agentExecution.profile.integrationEvents.some(event => event.action === "agent.learning.start_or_continue"));
  assert(agentExecution.profile.integrationEvents.some(event => event.action === "agent.workforce.match_role"));
  const notice = await call("/api/notifications/send", { module: "Learning", channel: "workflow", message: "Learning notification smoke" });
  assert(notice.profile.notifications.some(item => item.module === "Learning"));
  assert(notice.profile.integrationEvents.some(event => event.action === "notification.sent" && event.module === "Learning"));
  const demo = await call("/api/demo/run", {});
  assert(demo.profile.activity.some(item => item.includes("Executive demo run completed")));
  assert(demo.profile.integrationEvents.some(event => event.action === "demo.learning_completed"));
  assert(demo.profile.integrationEvents.some(event => event.action === "demo.workforce_synced"));
  assert(demo.profile.integrationEvents.some(event => event.action === "demo.health_case_opened"));
  assert(demo.profile.integrationEvents.some(event => event.action === "demo.trade_order_created"));
  assert(demo.profile.notifications.some(item => item.channel === "executive-demo"));
  const wowDemo = await call("/api/demo/wow", {});
  assert(wowDemo.profile.demoScore === 100);
  assert(wowDemo.profile.demoMoments.length >= 6);
  assert(wowDemo.profile.learningAccommodations.length >= 3);
  assert(wowDemo.profile.telehealthAccessibility.length >= 3);
  assert(wowDemo.profile.integrationEvents.some(event => event.action === "wow.telehealth_accessible"));
  assert(wowDemo.profile.integrationEvents.some(event => event.action === "wow.ai_orchestration"));
  assert(wowDemo.profile.notifications.some(item => item.channel === "wow-demo"));
  server.kill();
  fs.writeFileSync(dbPath, dbSnapshot);
  console.log("Smoke test passed");
})().catch(error => {
  fs.writeFileSync(dbPath, dbSnapshot);
  console.error(error.message);
  process.exit(1);
});
